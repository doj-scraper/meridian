# Agentic Orchestrator — PRD

## Original Problem Statement
Refactor the HTML Pipeline Studio V12 into a production-grade agentic orchestration system:
- Decouple UI from a headless engine
- DAG + state-machine hybrid workflow model
- Agent abstraction (inputs, outputs, handler, retry, memory)
- Shared context propagation
- Async execution with pause/resume and long-running tasks
- Structured event logging, tracing, telemetry
- Pluggable decision policies (rule, probabilistic, LLM)
- Failure handling (retries, backoff, rollback/compensation, circuit breakers)
- Modular architecture (engine, workflow spec, UI, adapters)
- Serializable, versioned, remotely executable workflows
- Preserve V12 visual/narrative UI as an event-subscribing layer

## User Choices
- Python FastAPI backend (unified orchestrator + agents for platform fit, module boundaries preserved so a Node.js orchestrator could slot in later)
- React frontend
- MongoDB persistence with optimistic concurrency + event sourcing
- WebSocket real-time streaming with replay (`?from_seq=N`)
- LLM policy wired via Emergent Universal Key (Claude Sonnet 4.5 default)
- DevOps pipeline as the canonical demo; engine is domain-agnostic

## Architecture
```
backend/
  server.py                  FastAPI routes + WebSocket
  engine/orchestrator.py     Async execution loop, retries, compensation
  agents/base.py, builtin.py Agent interface + SimulatedAction / Terminal / Decision
  policies/                  base + human + rule + probabilistic + llm + registry
  persistence/               Pydantic models + Mongo repo (versioned, event-sourced)
  transport/ws_manager.py    In-process pub/sub -> WebSocket fan-out
  workflows/devops_pipeline.json  Declarative 25-node / 30-edge DAG

frontend/src/
  components/PipelineStudio.jsx  Read-only event-driven renderer
  components/Icons.jsx           Workflow-data-driven icon set
  lib/orchestratorClient.js      REST + auto-reconnecting EventStream
```

## Mongo Collections
- `workflows` — versioned definitions (slug + version unique)
- `executions` — state with `version` (optimistic lock), `seq` (event counter), shared `context`, `phase_memory`, `node_attempts`, `node_results` (idempotency cache)
- `events` — append-only log with `(execution_id, seq)` unique index; replayable

## REST API (`/api` prefix)
- `GET /health`
- `GET /workflows` · `GET /workflows/{slug}` · `POST /workflows`
- `POST /executions` (body: slug, chaos_mode, policy_override)
- `GET /executions` · `GET /executions/{id}` · `GET /executions/{id}/events?from_seq=`
- `POST /executions/{id}/decide` · `/pause` · `/resume`
- `WS /ws/executions/{id}?from_seq=` (sends `_hello`, historical events, `_replay_done`, then live events, `_ping` keepalive)

## Implemented (Jan 2026)
- Declarative DAG workflow schema + JSON serialization
- Async orchestrator with per-node retry/backoff/timeout, compensation hook, phase transitions
- Four decision policies: `human`, `rule`, `probabilistic`, `llm` (Claude Sonnet 4.5 via Emergent key, strict-JSON prompt, low-confidence fallback to human)
- Shared context propagation (`context`) with idempotent node result cache
- MongoDB event sourcing with strictly-increasing `seq`; `version`-based optimistic concurrency
- WebSocket event streaming with replay + reconnect
- Pause/resume + human intervention ("decide") without losing in-memory state
- React UI fully event-driven: lanes/nodes/connectors/artifact memory/narrative strip + decision panel + event inspector drawer (Events / Traces / Circuits tabs)
- **OpenTelemetry tracing**: `workflow.execution` → `workflow.node` → `agent.attempt` / `policy.decide` spans with rich attributes; in-memory SpanCollector + `GET /api/executions/{id}/traces`; optional OTLP export via `OTEL_EXPORTER_OTLP_ENDPOINT`
- **Time-windowed Circuit Breaker** per handler (CLOSED/OPEN/HALF_OPEN), rolling failure window, configurable cool-down; emits `circuit_opened` / `circuit_closed` / `circuit_short_circuited` events; short-circuited nodes follow the declared failure edge; `GET /api/circuit-breakers`
- **All 26 backend tests pass** (18 regression + 8 new covering tracing + circuit breaker states)

## Backlog / P1-P2
- Distributed execution (multi-worker lease via `version` field is already designed; add worker id + heartbeat)
- Rule-based policy config UI
- Workflow visual editor (UI kit is already data-driven; enable drag-and-drop)
- Persist LLM policy call traces for explainability
- OpenTelemetry tracing spans per node (current telemetry is structured events only)
- Circuit breaker per handler (retries + backoff exist; add time-windowed open-state)

## Credentials
- Emergent Universal LLM Key stored in `/app/backend/.env` as `EMERGENT_LLM_KEY`
- No auth layer yet — add JWT/OAuth before multi-tenant deployment
