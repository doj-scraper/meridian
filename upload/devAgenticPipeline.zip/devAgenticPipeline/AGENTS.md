# Agents

An **Agent** is a pluggable unit of execution bound to a workflow node. This
document describes the agent contract, the built-in agents shipped with the
system, and the decision-policy layer that sits alongside them.

For the overall system architecture see [`ARCHITECTURE.md`](./ARCHITECTURE.md).

---

## The contract

```python
# backend/agents/base.py

@dataclass
class AgentResult:
    status: Literal["success", "failure"] = "success"
    outputs: dict[str, Any] = {}
    error: str | None = None
    condition: str | None = None   # "success" | "failure" — used by edges

class Agent:
    name: str = "base"

    async def run(self, node: NodeSpec, context: dict[str, Any]) -> AgentResult:
        ...
```

- **Pure-ish function**: agents receive the shared `context` and the
  `NodeSpec` they are bound to, and return an `AgentResult`.
- **No side effects** on the event log or persistence — the orchestrator is
  the sole writer. Agents may perform any external I/O they need (HTTP,
  filesystem, LLM calls) but must not touch Mongo or the event bus
  directly.
- **Timeouts + retries** are applied by the orchestrator based on the node
  spec. An agent that wants finer-grained backoff inside a single attempt
  should implement it internally, but the outer retry loop is the system's
  authoritative one.
- **Idempotency**: the orchestrator caches successful results in
  `state.node_results[node.id]`. A second visit to the same node within the
  same execution re-uses the cached result instead of calling the agent
  again. Agents should still strive to be idempotent so compensation and
  re-runs are safe.

---

## Registering an agent

```python
from agents.base import Agent, AgentResult, register

class HttpFetch(Agent):
    name = "http_fetch"

    async def run(self, node, context):
        url = node.inputs.get("url") if hasattr(node, "inputs") else context.get("url")
        resp = await http_client.get(url)
        return AgentResult(
            status="success" if resp.ok else "failure",
            outputs={"status_code": resp.status_code, "body": resp.text[:2048]},
            condition="success" if resp.ok else "failure",
        )

# During startup:
register("http_fetch", HttpFetch())
```

Then reference it from a workflow JSON by setting `"handler": "http_fetch"`.
The registry is populated at process startup via
`agents.builtin.register_builtins()`; add your own calls next to it.

---

## Built-in agents

### `simulate` — `SimulatedAction`

Generic placeholder used by the DevOps demo workflow. Sleeps 0.15–0.45s,
then returns success — unless `chaos_mode` is enabled **and** the node's
`failure_probability` rolls positive, in which case it returns a simulated
failure. Useful for exercising retries, circuit breakers, and the
compensation path without any real I/O.

### `terminal` — `Terminal`

Marker agent for `type: "terminal"` nodes. Returns success with a
`{"terminal": node.id}` output; the orchestrator is responsible for
interpreting the terminal semantics (follow trailing edges or complete the
workflow).

### `decision` — `DecisionGate`

Placeholder agent for `type: "decision"` nodes. The orchestrator never
calls `DecisionGate.run()` on the hot path — it invokes the policy layer
directly. The agent exists so the registry is complete and so future
variants (e.g., "decision with pre-flight validation") can slot in.

---

## Policy layer

Decision nodes delegate to a **Policy** strategy, not to an Agent. Policies
live in `backend/policies/`.

```python
# backend/policies/base.py

@dataclass
class PolicyDecision:
    action_id: str | None = None
    confidence: float = 0.0
    reasoning: str = ""
    needs_human: bool = False
    source: str = "unknown"

class Policy:
    name: str = "base"
    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        ...
```

Built-ins:

| Policy          | When to use                                              |
| --------------- | -------------------------------------------------------- |
| `human`         | Always emits `decision_required`; UI resolves it         |
| `rule`          | Deterministic `when: {ctx_key: value}` → `action_id` rules |
| `probabilistic` | Weighted random over outgoing edges (uses `edge.probability`) |
| `llm`           | Claude Sonnet 4.5 (via Emergent key) with strict JSON output |

The policy used for a node is selected in this priority order:

1. `ExecutionState.policy_override` (set when starting the execution — lets
   an operator force a mode without editing the workflow).
2. `node.policy.mode` in the workflow spec.
3. Default: `human`.

---

## LLM policy details

File: `backend/policies/llm_policy.py`

### Prompt shape

```json
{
  "node": { "id": "n25", "name": "Design Gate", "intent": "Quality Control" },
  "allowed_actions": [
    { "action_id": "approve", "label": "Approve", "severity": "clean",
      "narrative_hint": "Design Approved" },
    { "action_id": "reject",  "label": "Reject",  "severity": "warning",
      "narrative_hint": "Design Rejected (Loop)" }
  ],
  "context_snapshot": { ... },
  "recent_events": [ { "type": "...", "description": "...", "severity": "..." }, ... ]
}
```

### Required response shape

```json
{
  "decision": "<action_id>",
  "confidence": 0.0,
  "reasoning": "short explanation"
}
```

### Safety rails

- **Allowed-action enforcement**: if the LLM returns an `action_id` that is
  not in the outgoing edges, the policy falls back to `needs_human=True`.
- **Confidence threshold**: if `confidence < node.policy.min_confidence`
  (default 0.5), the policy falls back to human.
- **Parse errors**: malformed JSON or network failures also fall back to
  human — the system never proceeds on an unvalidated LLM decision.

The LLM call is made via `emergentintegrations.LlmChat`. Provider/model are
configurable per decision node:

```json
"policy": {
  "mode": "llm",
  "llm_provider": "anthropic",
  "llm_model": "claude-sonnet-4-5-20250929",
  "min_confidence": 0.6
}
```

---

## Writing a new policy

```python
from policies.base import Policy, PolicyDecision, register

class ThresholdPolicy(Policy):
    name = "threshold"
    async def decide(self, node, outgoing_edges, context, recent_events):
        if context.get("error_count", 0) > 3:
            return PolicyDecision(action_id="escalate", confidence=1.0,
                                  source="threshold",
                                  reasoning="Error count exceeded")
        return PolicyDecision(action_id="retry", confidence=0.8,
                              source="threshold")

register("threshold", ThresholdPolicy())
```

Then set `"policy": {"mode": "threshold"}` on any decision node, or pass
`policy_override="threshold"` when starting an execution.

---

## Operational concerns

- **Retries**: defined on the node (`retry_policy.max_attempts`), applied by
  the orchestrator around `agent.run`. Each attempt is its own OTEL span
  (`agent.attempt`).
- **Timeouts**: `node.timeout_s` wraps each attempt with `asyncio.wait_for`.
- **Circuit breakers**: keyed by `node.circuit_breaker.key` (defaults to
  `node.handler`). All nodes that share a handler share a breaker — if your
  `http_fetch` handler starts failing, every node using it short-circuits.
- **Compensation**: declare `"compensation": "<node_id>"` on a node; the
  orchestrator will emit `compensation_triggered` when that node fails. (The
  reference workflow uses this to highlight the rollback path; wiring the
  compensation node as a concrete follow-up is left to workflow authors.)
- **Shared context**: every agent's `outputs` dict is merged into
  `state.context` after a successful run and passed to subsequent agents.
  Keys prefixed with `_` (e.g. `_chaos_mode`) are control hints and are
  hidden from LLM prompts.
