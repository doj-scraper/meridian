# Pipeline Studio — Agentic Orchestrator

Production-grade agentic workflow orchestration engine with a live visual UI.

This is a refactor of the original single-file **Pipeline Studio V12** HTML demo
into a decoupled, event-driven system:

- **Headless Python orchestration engine** (FastAPI) — runs workflows as
  declarative DAGs, emits structured events.
- **MongoDB persistence** — versioned workflow specs, event-sourced execution
  history, optimistic concurrency control.
- **Pluggable decision policies** — `human`, `rule`, `probabilistic`, `llm`
  (Claude Sonnet 4.5 via Emergent Universal Key).
- **Real-time WebSocket streaming** — with event replay for reconnecting
  clients.
- **Observability** — OpenTelemetry tracing spans per node/attempt/policy-call,
  and per-handler time-windowed circuit breakers.
- **React UI** — read-only renderer; the V12 visual/narrative system is
  preserved exactly and now subscribes to engine events instead of driving
  them.

---

## Quick start

The app runs under `supervisor` in the provided container:

```bash
sudo supervisorctl status
# backend    RUNNING
# frontend   RUNNING
# mongodb    RUNNING
```

- Frontend:   `http://localhost:3000` (served via ingress as `REACT_APP_BACKEND_URL`)
- Backend:    `http://localhost:8001` — all routes under `/api`
- WebSocket:  `wss://<host>/api/ws/executions/{exec_id}`

Open the UI → click **Run Pipeline** → watch the 25-node DevOps workflow
execute. Use the **Policy** dropdown to swap decision strategies; check
**Chaos Mode** to enable probabilistic failures. The **Events** drawer has
three tabs: `events`, `traces`, `circuits`.

---

## Environment

Backend (`/app/backend/.env`):

```
MONGO_URL=mongodb://localhost:27017
DB_NAME=test_database
CORS_ORIGINS=*
EMERGENT_LLM_KEY=sk-emergent-...     # required for policy_override="llm"
# Optional:
# OTEL_EXPORTER_OTLP_ENDPOINT=http://collector:4318
```

Frontend (`/app/frontend/.env`):

```
REACT_APP_BACKEND_URL=https://<your-preview>.preview.emergentagent.com
```

---

## Key REST endpoints (all prefixed `/api`)

| Method & path                                     | Purpose                                          |
| ------------------------------------------------- | ------------------------------------------------ |
| `GET  /health`                                    | Liveness probe                                   |
| `GET  /workflows`                                 | List workflow definitions                        |
| `GET  /workflows/{slug}`                          | Fetch a workflow (optionally `?version=N`)       |
| `POST /workflows`                                 | Upsert a workflow definition                     |
| `POST /executions`                                | Start an execution (body: slug, chaos_mode, policy_override) |
| `GET  /executions`                                | List recent executions                           |
| `GET  /executions/{id}`                           | Current state snapshot                           |
| `GET  /executions/{id}/events?from_seq=N`         | Event log (event sourcing)                       |
| `GET  /executions/{id}/traces`                    | OpenTelemetry spans (in-memory collector)        |
| `POST /executions/{id}/decide`                    | Submit a human decision `{action_id}`            |
| `POST /executions/{id}/pause` \| `/resume`        | Control flow                                     |
| `GET  /circuit-breakers`                          | Snapshot of all handler circuit breakers         |
| `WS   /ws/executions/{id}?from_seq=N`             | Replay + live event stream                       |

---

## Repository layout

```
backend/
  server.py                         FastAPI app, REST + WebSocket
  engine/
    orchestrator.py                 Async execution loop
    tracing.py                      OpenTelemetry setup + in-memory span store
    circuit_breaker.py              Per-handler CLOSED/OPEN/HALF_OPEN state
  agents/
    base.py                         Agent interface + registry
    builtin.py                      SimulatedAction / Terminal / DecisionGate
  policies/
    base.py, human_policy.py, rule_policy.py,
    probabilistic_policy.py, llm_policy.py, registry.py
  persistence/
    models.py                       Pydantic models (ExecutionState, Event, ...)
    repository.py                   Async Mongo repo + optimistic concurrency
  transport/
    ws_manager.py                   In-process pub/sub for WebSocket fan-out
  workflows/
    devops_pipeline.json            Canonical 25-node / 30-edge DAG
    loader.py
  tests/                            Backend test suites

frontend/
  src/
    App.js, App.css
    components/
      PipelineStudio.jsx            UI renderer (no orchestration logic)
      Icons.jsx                     Data-driven icon glyphs
    lib/
      orchestratorClient.js         REST client + auto-reconnecting EventStream
```

For deeper detail see [`ARCHITECTURE.md`](./ARCHITECTURE.md) and
[`AGENTS.md`](./AGENTS.md).

---

## Design principles

1. **Engine knows nothing about UI.** All visuals are derived from an event
   stream + workflow spec.
2. **Workflows are data.** No DevOps-specific logic in the engine; adding a
   workflow means adding a JSON file (or a row in the `workflows` collection).
3. **Every transition is persisted.** Event sourcing + optimistic locking
   make replay and future distributed execution straightforward.
4. **Policies are pluggable.** Decision nodes delegate to a strategy;
   `human`, `rule`, `probabilistic`, `llm` all implement the same interface.
5. **Failures are first-class.** Retries with exponential backoff,
   compensation hooks, and circuit breakers are part of the node spec, not
   ad-hoc code paths.

---

## Testing

```bash
cd /app/backend
pytest -q
```

Current status: **26 / 26 tests passing** (engine lifecycle, REST, WebSocket
replay, optimistic concurrency, all four policy modes, chaos mode, tracing,
circuit breaker state transitions).
