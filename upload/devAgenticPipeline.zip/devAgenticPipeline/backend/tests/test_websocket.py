"""
WebSocket Tests for Agentic Orchestrator
Tests: WebSocket connection, replay, live streaming
"""
import pytest
import requests
import asyncio
import json
import os

# Get BASE_URL from environment
BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    raise ValueError("REACT_APP_BACKEND_URL environment variable not set")

# Convert HTTP URL to WebSocket URL
WS_URL = BASE_URL.replace("https://", "wss://").replace("http://", "ws://")


class TestWebSocketConnection:
    """Test WebSocket connection and replay"""
    
    @pytest.mark.asyncio
    async def test_websocket_connection_and_replay(self):
        """Connect to WebSocket, receive _hello, events, and _replay_done"""
        import websockets
        
        # First, start an execution
        response = requests.post(f"{BASE_URL}/api/executions", json={
            "workflow_slug": "devops_pipeline",
            "policy_override": "probabilistic"
        })
        assert response.status_code == 200
        exec_id = response.json().get("id")
        print(f"✓ Started execution: {exec_id}")
        
        # Wait for some events to be generated
        await asyncio.sleep(2)
        
        # Connect to WebSocket
        ws_endpoint = f"{WS_URL}/api/ws/executions/{exec_id}?from_seq=0"
        print(f"Connecting to: {ws_endpoint}")
        
        messages = []
        try:
            async with websockets.connect(ws_endpoint, close_timeout=5) as ws:
                # Receive messages with timeout
                for _ in range(50):  # Max 50 messages
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
                        data = json.loads(msg)
                        messages.append(data)
                        
                        if data.get("type") == "_replay_done":
                            print(f"✓ Received _replay_done")
                            break
                    except asyncio.TimeoutError:
                        break
        except Exception as e:
            print(f"WebSocket error: {e}")
        
        # Validate messages
        assert len(messages) > 0, "Expected at least one message"
        
        # First message should be _hello
        assert messages[0].get("type") == "_hello", f"First message should be _hello, got {messages[0].get('type')}"
        print(f"✓ Received _hello with execution state")
        
        # Should have event messages
        event_messages = [m for m in messages if m.get("type") == "event"]
        assert len(event_messages) > 0, "Expected event messages"
        print(f"✓ Received {len(event_messages)} event messages")
        
        # Should have _replay_done
        replay_done = [m for m in messages if m.get("type") == "_replay_done"]
        assert len(replay_done) > 0, "Expected _replay_done message"
        print(f"✓ WebSocket replay test passed")
    
    @pytest.mark.asyncio
    async def test_websocket_events_match_rest_endpoint(self):
        """WebSocket events should match REST /events endpoint"""
        import websockets
        
        # Start an execution and wait for completion
        response = requests.post(f"{BASE_URL}/api/executions", json={
            "workflow_slug": "devops_pipeline",
            "policy_override": "probabilistic"
        })
        assert response.status_code == 200
        exec_id = response.json().get("id")
        
        # Wait for completion
        max_wait = 20
        import time
        start_time = time.time()
        while time.time() - start_time < max_wait:
            resp = requests.get(f"{BASE_URL}/api/executions/{exec_id}")
            if resp.json().get("status") in ["completed", "failed"]:
                break
            await asyncio.sleep(0.5)
        
        # Get events from REST endpoint
        rest_response = requests.get(f"{BASE_URL}/api/executions/{exec_id}/events?from_seq=0")
        rest_events = rest_response.json()
        
        # Connect to WebSocket and get events
        ws_endpoint = f"{WS_URL}/api/ws/executions/{exec_id}?from_seq=0"
        ws_events = []
        
        try:
            async with websockets.connect(ws_endpoint, close_timeout=5) as ws:
                for _ in range(100):
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=3.0)
                        data = json.loads(msg)
                        if data.get("type") == "event":
                            ws_events.append(data.get("event"))
                        if data.get("type") == "_replay_done":
                            break
                    except asyncio.TimeoutError:
                        break
        except Exception as e:
            print(f"WebSocket error: {e}")
        
        # Compare event counts
        print(f"REST events: {len(rest_events)}, WS events: {len(ws_events)}")
        
        # WS events should match REST events (at least the replayed ones)
        if ws_events and rest_events:
            # Compare first few events
            for i in range(min(5, len(ws_events), len(rest_events))):
                assert ws_events[i].get("seq") == rest_events[i].get("seq"), f"Event seq mismatch at index {i}"
                assert ws_events[i].get("type") == rest_events[i].get("type"), f"Event type mismatch at index {i}"
            print(f"✓ WebSocket events match REST endpoint")


# Run tests if executed directly
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
