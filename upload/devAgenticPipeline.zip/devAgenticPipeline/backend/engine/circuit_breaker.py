"""Time-windowed circuit breaker keyed by a stable handler identifier.

States:
  CLOSED    - Normal operation. Failures accumulate inside a rolling window.
  OPEN      - All calls short-circuit. Transitions to HALF_OPEN after the
              configured cool-down expires.
  HALF_OPEN - Exactly one trial request is allowed through. Success closes
              the breaker; another failure re-opens it.

A CircuitBreaker is safe for concurrent use inside a single asyncio event
loop; we do not need a lock because asyncio tasks don't preempt each other.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class CircuitBreaker:
    key: str
    failure_threshold: int = 5           # failures within window -> trip
    window_s: float = 60.0               # rolling failure window
    open_duration_s: float = 30.0        # cool-down before probing
    state: CircuitState = CircuitState.CLOSED
    _failures: deque = field(default_factory=deque)
    _opened_at: float | None = None
    _half_open_in_flight: bool = False

    def _purge(self, now: float) -> None:
        cutoff = now - self.window_s
        while self._failures and self._failures[0] < cutoff:
            self._failures.popleft()

    def allow(self) -> bool:
        """Returns True if a call may proceed. Also performs OPEN->HALF_OPEN
        transition when cool-down has elapsed."""
        now = time.monotonic()
        if self.state == CircuitState.OPEN:
            if self._opened_at is not None and (now - self._opened_at) >= self.open_duration_s:
                self.state = CircuitState.HALF_OPEN
                self._half_open_in_flight = False
            else:
                return False
        if self.state == CircuitState.HALF_OPEN:
            if self._half_open_in_flight:
                return False
            self._half_open_in_flight = True
            return True
        return True

    def record_success(self) -> CircuitState | None:
        """Returns the new state if it changed, else None.
        
        Note: In CLOSED state, successes do NOT clear the failure history.
        Failures are only cleared when transitioning from OPEN/HALF_OPEN to CLOSED,
        or when they expire outside the rolling window.
        """
        self._half_open_in_flight = False
        if self.state != CircuitState.CLOSED:
            self.state = CircuitState.CLOSED
            self._failures.clear()
            self._opened_at = None
            return self.state
        # In CLOSED state, do NOT clear failures - let them expire naturally via window
        return None

    def record_failure(self) -> CircuitState | None:
        now = time.monotonic()
        self._half_open_in_flight = False

        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN
            self._opened_at = now
            return self.state

        self._failures.append(now)
        self._purge(now)
        if len(self._failures) >= self.failure_threshold and self.state != CircuitState.OPEN:
            self.state = CircuitState.OPEN
            self._opened_at = now
            return self.state
        return None

    def snapshot(self) -> dict:
        now = time.monotonic()
        self._purge(now)
        return {
            "key": self.key,
            "state": self.state.value,
            "failures_in_window": len(self._failures),
            "window_s": self.window_s,
            "failure_threshold": self.failure_threshold,
            "open_duration_s": self.open_duration_s,
            "opened_at": self._opened_at,
        }


class CircuitBreakerRegistry:
    def __init__(self) -> None:
        self._breakers: dict[str, CircuitBreaker] = {}

    def get_or_create(
        self,
        key: str,
        failure_threshold: int = 5,
        window_s: float = 60.0,
        open_duration_s: float = 30.0,
    ) -> CircuitBreaker:
        cb = self._breakers.get(key)
        if cb is None:
            cb = CircuitBreaker(
                key=key,
                failure_threshold=failure_threshold,
                window_s=window_s,
                open_duration_s=open_duration_s,
            )
            self._breakers[key] = cb
        return cb

    def all(self) -> list[dict]:
        return [cb.snapshot() for cb in self._breakers.values()]


registry = CircuitBreakerRegistry()
