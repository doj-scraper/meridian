"""Async orchestration engine.

Responsibilities:
  * Load / persist execution state (with optimistic concurrency)
  * Invoke agents with retry + backoff + timeout
  * Resolve next edge via condition / policy
  * Emit events through the event bus and append to the event log
  * Support pause / resume / decide (external control)
  * Run compensation (rollback) nodes on failure

The engine owns NO UI logic and NO domain-specific knowledge.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from opentelemetry import trace as _otel_trace
from opentelemetry.trace import Status, StatusCode

import agents.base as agents_registry
import policies.base as policies_registry
from engine.circuit_breaker import CircuitState, registry as cb_registry
from engine.tracing import tracer
from persistence import repository as repo
from persistence.models import (
    EdgeSpec,
    Event,
    EventType,
    ExecutionState,
    ExecutionStatus,
    NodeSpec,
    WorkflowSpec,
)
from policies.base import PolicyDecision
from transport.ws_manager import bus

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Workflow index helpers
# ---------------------------------------------------------------------------
class WorkflowIndex:
    def __init__(self, wf: WorkflowSpec) -> None:
        self.wf = wf
        self.nodes: dict[str, NodeSpec] = {n.id: n for n in wf.nodes}
        self.edges_from: dict[str, list[EdgeSpec]] = {}
        for e in wf.edges:
            self.edges_from.setdefault(e.from_, []).append(e)

    def outgoing(self, node_id: str) -> list[EdgeSpec]:
        return self.edges_from.get(node_id, [])


# ---------------------------------------------------------------------------
# In-memory registry of running execution tasks (single-node deployment)
# ---------------------------------------------------------------------------
_tasks: dict[str, asyncio.Task] = {}
_control_flags: dict[str, dict[str, Any]] = {}  # exec_id -> {"pause": bool, "decision_event": Event}


def _flags_for(exec_id: str) -> dict[str, Any]:
    if exec_id not in _control_flags:
        _control_flags[exec_id] = {
            "pause": False,
            "decision": asyncio.Event(),
            "decision_value": None,  # action_id string once set
        }
    return _control_flags[exec_id]


# ---------------------------------------------------------------------------
# Event emission
# ---------------------------------------------------------------------------
async def _emit(state: ExecutionState, type_: EventType, description: str, severity: str = "info", payload: dict[str, Any] | None = None) -> Event:
    state.seq += 1
    evt = Event(
        execution_id=state.id,
        seq=state.seq,
        type=type_,
        severity=severity,  # type: ignore[arg-type]
        description=description,
        payload=payload or {},
    )
    await repo.append_event(evt)
    await bus.publish(evt)
    return evt


async def _persist_seq(state: ExecutionState) -> None:
    """Persist current in-memory seq/state so a subsequent resume loads the
    correct seq counter. Silently swallows concurrency errors (the loop will
    re-try on the next save)."""
    try:
        await repo.save_execution(state)
    except repo.ConcurrencyError:
        pass


# ---------------------------------------------------------------------------
# Public control API
# ---------------------------------------------------------------------------
async def start_execution(
    workflow: WorkflowSpec,
    chaos_mode: bool = False,
    policy_override: str | None = None,
) -> ExecutionState:
    state = ExecutionState(
        workflow_id=workflow.id,
        workflow_slug=workflow.slug,
        workflow_version=workflow.version,
        current_node_id=workflow.entry_node_id,
        status=ExecutionStatus.PENDING,
        chaos_mode=chaos_mode,
        policy_override=policy_override,
        context={"_chaos_mode": chaos_mode},
    )
    await repo.create_execution(state)
    task = asyncio.create_task(_run_loop(state.id))
    _tasks[state.id] = task
    return state


async def pause_execution(exec_id: str) -> None:
    _flags_for(exec_id)["pause"] = True


async def resume_execution(exec_id: str) -> None:
    flags = _flags_for(exec_id)
    flags["pause"] = False
    state = await repo.get_execution(exec_id)
    if state is None:
        return
    # Only spawn a new loop if the previous one has exited (paused state).
    if state.status == ExecutionStatus.PAUSED:
        state.status = ExecutionStatus.RUNNING
        await repo.save_execution(state)
        await _emit(state, EventType.EXECUTION_RESUMED, "Execution resumed")
        if exec_id not in _tasks or _tasks[exec_id].done():
            _tasks[exec_id] = asyncio.create_task(_run_loop(exec_id))


async def submit_decision(exec_id: str, action_id: str) -> None:
    flags = _flags_for(exec_id)
    flags["decision_value"] = action_id
    # The running loop (blocked inside _resolve_decision) will handle the
    # status transition and persistence itself. We only flip the asyncio.Event.
    ev = flags.get("decision")
    if isinstance(ev, asyncio.Event):
        ev.set()
    # Fallback: if for some reason the loop died, spawn a new one.
    if exec_id not in _tasks or _tasks[exec_id].done():
        _tasks[exec_id] = asyncio.create_task(_run_loop(exec_id))


# ---------------------------------------------------------------------------
# Internal run loop
# ---------------------------------------------------------------------------
async def _run_loop(exec_id: str) -> None:
    try:
        state = await repo.get_execution(exec_id)
        if state is None:
            return

        from workflows.loader import load_devops  # lazy import to avoid cycle at import time
        wf = await repo.get_workflow(state.workflow_id)
        if wf is None:
            wf = load_devops()
        index = WorkflowIndex(wf)

        root_span = tracer().start_span(
            "workflow.execution",
            attributes={
                "execution.id": state.id,
                "workflow.slug": wf.slug,
                "workflow.version": wf.version,
                "chaos_mode": state.chaos_mode,
                "policy_override": state.policy_override or "",
            },
        )
        root_ctx = _otel_trace.set_span_in_context(root_span)
        final_status_for_span = "ok"

        try:
            if state.status == ExecutionStatus.PENDING:
                state.status = ExecutionStatus.RUNNING
                await repo.save_execution(state)
                await _emit(
                    state,
                    EventType.EXECUTION_STARTED,
                    f"Execution started: {wf.name}",
                    severity="info",
                    payload={"workflow_slug": wf.slug, "chaos_mode": state.chaos_mode},
                )
                first_node = index.nodes.get(state.current_node_id or wf.entry_node_id)
                if first_node:
                    await _emit(
                        state,
                        EventType.PHASE_ENTERED,
                        f"Phase: {first_node.phase}",
                        payload={"phase": first_node.phase},
                    )

            last_phase = None
            if state.current_node_id:
                first_node = index.nodes.get(state.current_node_id)
                if first_node:
                    last_phase = first_node.phase

            while True:
                if state.current_node_id is None:
                    break
                if state.status in {ExecutionStatus.COMPLETED, ExecutionStatus.FAILED}:
                    break

                flags = _flags_for(exec_id)
                if flags["pause"]:
                    state.status = ExecutionStatus.PAUSED
                    await repo.save_execution(state)
                    await _emit(state, EventType.EXECUTION_PAUSED, "Execution paused")
                    await _persist_seq(state)
                    final_status_for_span = "paused"
                    break

                node = index.nodes.get(state.current_node_id)
                if node is None:
                    state.status = ExecutionStatus.FAILED
                    state.last_error = f"Unknown node {state.current_node_id}"
                    await repo.save_execution(state)
                    await _emit(state, EventType.WORKFLOW_FAILED, state.last_error, severity="critical")
                    await _persist_seq(state)
                    final_status_for_span = "error"
                    break

                # Phase change
                if node.phase != last_phase:
                    if last_phase is not None:
                        await _emit(
                            state,
                            EventType.PHASE_COMPLETED,
                            f"Phase complete: {last_phase}",
                            payload={"phase": last_phase, "memory": state.phase_memory.get(last_phase, "clean")},
                        )
                    await _emit(
                        state,
                        EventType.PHASE_ENTERED,
                        f"Phase: {node.phase}",
                        payload={"phase": node.phase},
                    )
                    last_phase = node.phase
                    state.phase_memory.setdefault(node.phase, "clean")
                    await repo.save_execution(state)

                # Node span covers every node type (decision / terminal / action)
                with tracer().start_as_current_span(
                    "workflow.node",
                    context=root_ctx,
                    attributes={
                        "execution.id": state.id,
                        "node.id": node.id,
                        "node.name": node.name,
                        "node.phase": node.phase,
                        "node.role": node.role,
                        "node.type": node.type,
                        "node.handler": node.handler,
                    },
                ) as node_span:
                    if node.type == "decision":
                        decision = await _resolve_decision(state, node, index.outgoing(node.id))
                        if decision is None:
                            node_span.set_attribute("node.outcome", "awaiting_decision")
                            final_status_for_span = "awaiting_decision"
                            return  # break is handled by the outer finally; we still want to close the root span
                        next_node_id, severity, narrative = decision
                        node_span.set_attribute("node.outcome", "decided")
                        node_span.set_attribute("edge.to", next_node_id)
                        node_span.set_attribute("edge.severity", severity)
                        await _emit(
                            state,
                            EventType.EDGE_TRAVERSED,
                            narrative or f"{node.name} -> {next_node_id}",
                            severity=severity,
                            payload={"from": node.id, "to": next_node_id, "severity": severity, "narrative": narrative},
                        )
                        _bump_phase_memory(state, node.phase, severity)
                        state.current_node_id = next_node_id
                        await repo.save_execution(state)
                        continue

                    if node.type == "terminal":
                        await _emit(state, EventType.NODE_STARTED, f"{node.name} started", payload={"node_id": node.id})
                        await _emit(state, EventType.NODE_COMPLETED, f"{node.name} completed", severity="clean", payload={"node_id": node.id})
                        outs = index.outgoing(node.id)
                        if outs:
                            nxt = outs[0]
                            node_span.set_attribute("node.outcome", "terminal_chained")
                            await _emit(
                                state,
                                EventType.EDGE_TRAVERSED,
                                nxt.narrative or f"{node.name} -> {nxt.to}",
                                severity=nxt.severity,
                                payload={"from": node.id, "to": nxt.to, "severity": nxt.severity},
                            )
                            state.current_node_id = nxt.to
                            await repo.save_execution(state)
                            continue

                        node_span.set_attribute("node.outcome", "completed")
                        state.status = ExecutionStatus.COMPLETED
                        state.finished_at = _now()
                        await repo.save_execution(state)
                        await _emit(state, EventType.WORKFLOW_COMPLETED, "Workflow completed", severity="clean")
                        await _persist_seq(state)
                        break

                    # Action node
                    await _execute_action(state, node, index)
                    node_span.set_attribute(
                        "node.outcome",
                        state.node_results.get(node.id, {}).get("status", "unknown"),
                    )
                    node_span.set_attribute("node.attempts", state.node_attempts.get(node.id, 0))
                    if state.status == ExecutionStatus.COMPLETED:
                        await _emit(state, EventType.WORKFLOW_COMPLETED, "Workflow completed", severity="clean")
                        await _persist_seq(state)
                        break
                    if state.status == ExecutionStatus.FAILED:
                        await _persist_seq(state)
                        final_status_for_span = "error"
                        break
        finally:
            if final_status_for_span == "error":
                root_span.set_status(Status(StatusCode.ERROR))
            root_span.set_attribute("execution.final_status", state.status.value if state else "unknown")
            root_span.end()
    except Exception as exc:  # noqa: BLE001
        logger.exception("Run loop crashed: %s", exc)
        state = await repo.get_execution(exec_id)
        if state and state.status not in {ExecutionStatus.COMPLETED, ExecutionStatus.FAILED}:
            state.status = ExecutionStatus.FAILED
            state.last_error = str(exc)
            try:
                await repo.save_execution(state)
            except Exception:  # noqa: BLE001
                pass
            await _emit(state, EventType.WORKFLOW_FAILED, str(exc), severity="critical")


# ---------------------------------------------------------------------------
# Action execution: retry + backoff + compensation
# ---------------------------------------------------------------------------
async def _execute_action(state: ExecutionState, node: NodeSpec, index: WorkflowIndex) -> None:
    # Idempotency: if node already has a cached "success" result, skip re-run.
    cached = state.node_results.get(node.id)
    if cached and cached.get("status") == "success":
        await _emit(
            state,
            EventType.NODE_COMPLETED,
            f"{node.name} (cached)",
            severity="clean",
            payload={"node_id": node.id, "cached": True},
        )
        _advance_after_action(state, node, index, condition="success", severity="clean")
        await repo.save_execution(state)
        return

    # Circuit breaker short-circuit
    cb_cfg = node.circuit_breaker
    cb = None
    if cb_cfg.enabled:
        cb_key = cb_cfg.key or node.handler
        cb = cb_registry.get_or_create(
            cb_key,
            failure_threshold=cb_cfg.failure_threshold,
            window_s=cb_cfg.window_s,
            open_duration_s=cb_cfg.open_duration_s,
        )
        if not cb.allow():
            snap = cb.snapshot()
            await _emit(
                state,
                EventType.CIRCUIT_SHORT_CIRCUITED,
                f"Circuit OPEN for '{cb_key}' — skipping {node.name}",
                severity="critical",
                payload={"node_id": node.id, "circuit": snap},
            )
            last_error = f"circuit open for handler '{cb_key}'"
            state.node_results[node.id] = {"status": "failure", "error": last_error}
            state.last_error = last_error
            await _emit(
                state,
                EventType.NODE_FAILED,
                f"{node.name} failed: {last_error}",
                severity="critical",
                payload={"node_id": node.id, "error": last_error},
            )
            # Follow failure edge if declared, else fail workflow
            fail_edge = next((e for e in index.outgoing(node.id) if e.condition == "failure"), None)
            if fail_edge is None:
                state.status = ExecutionStatus.FAILED
                state.finished_at = _now()
                await repo.save_execution(state)
                await _emit(state, EventType.WORKFLOW_FAILED, state.last_error or "failure", severity="critical")
                return
            _bump_phase_memory(state, node.phase, "critical")
            await _emit(
                state,
                EventType.EDGE_TRAVERSED,
                fail_edge.narrative or f"{node.name} -> {fail_edge.to}",
                severity="critical",
                payload={"from": node.id, "to": fail_edge.to, "severity": "critical"},
            )
            state.current_node_id = fail_edge.to
            await repo.save_execution(state)
            return

    await _emit(state, EventType.NODE_STARTED, f"{node.name} started", payload={"node_id": node.id})

    agent = agents_registry.get(node.handler)
    rp = node.retry_policy
    attempt = 0
    last_error: str | None = None
    result = None

    while attempt < max(1, rp.max_attempts):
        attempt += 1
        state.node_attempts[node.id] = attempt
        with tracer().start_as_current_span(
            "agent.attempt",
            attributes={
                "execution.id": state.id,
                "node.id": node.id,
                "node.handler": node.handler,
                "attempt": attempt,
                "max_attempts": rp.max_attempts,
            },
        ) as attempt_span:
            try:
                result = await asyncio.wait_for(agent.run(node, state.context), timeout=node.timeout_s)
                attempt_span.set_attribute("attempt.status", result.status)
                if result.status == "success":
                    break
                last_error = result.error or "action returned failure"
                attempt_span.set_attribute("attempt.error", last_error)
            except asyncio.TimeoutError:
                last_error = f"timeout after {node.timeout_s}s"
                attempt_span.set_status(Status(StatusCode.ERROR, last_error))
                attempt_span.set_attribute("attempt.status", "timeout")
            except Exception as exc:  # noqa: BLE001
                last_error = f"{type(exc).__name__}: {exc}"
                attempt_span.set_status(Status(StatusCode.ERROR, last_error))
                attempt_span.set_attribute("attempt.status", "exception")

        if attempt < rp.max_attempts:
            backoff = min(rp.max_backoff_s, rp.base_backoff_s * (2 ** (attempt - 1)))
            await _emit(
                state,
                EventType.NODE_RETRY,
                f"{node.name} retry {attempt}/{rp.max_attempts} in {backoff:.2f}s",
                severity="warning",
                payload={"node_id": node.id, "attempt": attempt, "backoff_s": backoff, "error": last_error},
            )
            await asyncio.sleep(backoff)

    # All attempts done
    if result and result.status == "success":
        if cb is not None:
            prev_state = cb.state
            new_state = cb.record_success()
            if new_state is CircuitState.CLOSED and prev_state != CircuitState.CLOSED:
                await _emit(
                    state,
                    EventType.CIRCUIT_CLOSED,
                    f"Circuit CLOSED for '{cb.key}' after successful probe",
                    severity="info",
                    payload={"circuit": cb.snapshot()},
                )
        state.node_results[node.id] = {"status": "success", "outputs": result.outputs}
        state.context.update(result.outputs or {})
        await _emit(
            state,
            EventType.NODE_COMPLETED,
            f"{node.name} completed",
            severity="clean",
            payload={"node_id": node.id, "outputs": result.outputs},
        )
        _advance_after_action(state, node, index, condition="success", severity="clean")
        await repo.save_execution(state)
        return

    # Failure path
    if cb is not None:
        prev_state = cb.state
        new_state = cb.record_failure()
        if new_state is CircuitState.OPEN and prev_state != CircuitState.OPEN:
            await _emit(
                state,
                EventType.CIRCUIT_OPENED,
                f"Circuit OPENED for '{cb.key}' (threshold reached)",
                severity="critical",
                payload={"circuit": cb.snapshot()},
            )
    state.node_results[node.id] = {"status": "failure", "error": last_error}
    state.last_error = last_error
    await _emit(
        state,
        EventType.NODE_FAILED,
        f"{node.name} failed: {last_error}",
        severity="critical",
        payload={"node_id": node.id, "error": last_error},
    )

    # Compensation (rollback)
    if node.compensation and node.compensation in index.nodes:
        await _emit(
            state,
            EventType.COMPENSATION_TRIGGERED,
            f"Compensating via {node.compensation}",
            severity="warning",
            payload={"node_id": node.id, "compensation_node_id": node.compensation},
        )

    # Route to failure edge if declared; else fail workflow
    fail_edge = next(
        (e for e in index.outgoing(node.id) if e.condition == "failure"), None
    )
    if fail_edge is None:
        state.status = ExecutionStatus.FAILED
        state.finished_at = _now()
        await repo.save_execution(state)
        await _emit(state, EventType.WORKFLOW_FAILED, state.last_error or "failure", severity="critical")
        return

    _bump_phase_memory(state, node.phase, "critical")
    await _emit(
        state,
        EventType.EDGE_TRAVERSED,
        fail_edge.narrative or f"{node.name} -> {fail_edge.to}",
        severity="critical",
        payload={"from": node.id, "to": fail_edge.to, "severity": "critical"},
    )
    state.current_node_id = fail_edge.to
    await repo.save_execution(state)


def _advance_after_action(state: ExecutionState, node: NodeSpec, index: WorkflowIndex, condition: str, severity: str) -> None:
    edges = index.outgoing(node.id)
    # If chaos mode: let a probabilistic roll decide between condition edges
    if state.chaos_mode:
        import random

        cond_edges = [e for e in edges if e.condition in (None, "success", "failure") and e.probability is not None]
        if cond_edges:
            weights = [e.probability or 0.0 for e in cond_edges]
            total = sum(weights) or 1.0
            r = random.random() * total
            acc = 0.0
            chosen = cond_edges[-1]
            for e, w in zip(cond_edges, weights):
                acc += w
                if r <= acc:
                    chosen = e
                    break
            _bump_phase_memory(state, node.phase, chosen.severity)
            state.current_node_id = chosen.to
            return

    # Else deterministic: pick edge matching condition, else first unconditional
    chosen: EdgeSpec | None = None
    for e in edges:
        if e.condition == condition:
            chosen = e
            break
    if chosen is None:
        for e in edges:
            if e.condition is None:
                chosen = e
                break
    if chosen is None and edges:
        chosen = edges[0]

    if chosen is None:
        # No outgoing => completion handled by terminal type; here we mark done
        state.status = ExecutionStatus.COMPLETED
        state.finished_at = _now()
        return

    _bump_phase_memory(state, node.phase, chosen.severity)
    state.current_node_id = chosen.to


def _bump_phase_memory(state: ExecutionState, phase: str, severity: str) -> None:
    cur = state.phase_memory.get(phase, "clean")
    rank = {"clean": 0, "warning": 1, "critical": 2}
    if rank.get(severity, 0) > rank.get(cur, 0):
        state.phase_memory[phase] = severity


# ---------------------------------------------------------------------------
# Decision resolution
# ---------------------------------------------------------------------------
async def _resolve_decision(
    state: ExecutionState, node: NodeSpec, edges: list[EdgeSpec]
) -> tuple[str, str, str] | None:
    """Return (next_node_id, severity, narrative) or None when awaiting human."""
    mode = state.policy_override or (node.policy.mode if node.policy else "human")

    # Gather recent events for LLM context
    recent_events = []
    try:
        ev_list = await repo.list_events(state.id, from_seq=max(0, state.seq - 12))
        recent_events = [{"type": e.type.value, "description": e.description, "severity": e.severity} for e in ev_list]
    except Exception:  # noqa: BLE001
        recent_events = []

    policy = policies_registry.get(mode)
    with tracer().start_as_current_span(
        "policy.decide",
        attributes={
            "execution.id": state.id,
            "node.id": node.id,
            "policy.mode": mode,
            "policy.candidates": len(edges),
        },
    ) as policy_span:
        decision: PolicyDecision = await policy.decide(node, edges, state.context, recent_events)
        policy_span.set_attribute("policy.source", decision.source)
        policy_span.set_attribute("policy.confidence", decision.confidence)
        policy_span.set_attribute("policy.needs_human", decision.needs_human)
        if decision.action_id:
            policy_span.set_attribute("policy.action_id", decision.action_id)

    if decision.needs_human or decision.action_id is None:
        # Emit decision_required and block
        state.status = ExecutionStatus.AWAITING_DECISION
        state.pending_decision_node_id = node.id
        await repo.save_execution(state)
        await _emit(
            state,
            EventType.DECISION_REQUIRED,
            f"Decision required: {node.intent or node.name}",
            severity="warning",
            payload={
                "node_id": node.id,
                "intent": node.intent,
                "options": [
                    {
                        "action_id": e.action_id or f"{e.from_}->{e.to}",
                        "label": e.label or e.action_id or "Proceed",
                        "target": e.to,
                        "severity": e.severity,
                        "narrative": e.narrative,
                        "icon": e.label,  # reserved for future
                    }
                    for e in edges
                ],
                "policy_hint": {
                    "source": decision.source,
                    "confidence": decision.confidence,
                    "suggested_action": decision.action_id,
                    "reasoning": decision.reasoning,
                },
            },
        )
        # Persist the new seq so a crash-restart path reloads the correct counter.
        await _persist_seq(state)
        flags = _flags_for(state.id)
        flags["decision"] = asyncio.Event()
        await flags["decision"].wait()
        action_id = flags["decision_value"]
        flags["decision_value"] = None
        # resolve edge by action_id
        picked = next((e for e in edges if (e.action_id or f"{e.from_}->{e.to}") == action_id), None)
        if picked is None:
            picked = edges[0] if edges else None
        if picked is None:
            state.status = ExecutionStatus.FAILED
            await repo.save_execution(state)
            await _emit(state, EventType.WORKFLOW_FAILED, "No valid decision edge", severity="critical")
            return None
        state.pending_decision_node_id = None
        state.status = ExecutionStatus.RUNNING
        await _emit(
            state,
            EventType.DECISION_MADE,
            f"Decision: {picked.label or picked.action_id} (human)",
            severity=picked.severity,
            payload={
                "node_id": node.id,
                "action_id": picked.action_id,
                "source": "human",
                "confidence": 1.0,
            },
        )
        return picked.to, picked.severity, picked.narrative or picked.label or ""

    # Policy produced a decision
    picked = next(
        (e for e in edges if (e.action_id or f"{e.from_}->{e.to}") == decision.action_id), None
    )
    if picked is None and edges:
        picked = edges[0]
    if picked is None:
        state.status = ExecutionStatus.FAILED
        await repo.save_execution(state)
        return None

    await _emit(
        state,
        EventType.DECISION_MADE,
        f"Decision: {picked.label or picked.action_id} ({decision.source})",
        severity=picked.severity,
        payload={
            "node_id": node.id,
            "action_id": picked.action_id,
            "source": decision.source,
            "confidence": decision.confidence,
            "reasoning": decision.reasoning,
        },
    )
    return picked.to, picked.severity, picked.narrative or picked.label or ""


# ---------------------------------------------------------------------------
def _now():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc)
