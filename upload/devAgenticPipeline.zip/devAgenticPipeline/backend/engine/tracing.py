"""OpenTelemetry tracing setup + in-memory span store.

Every workflow execution becomes a trace. Each node becomes a child span,
with attempts and policy calls as grandchildren.

A simple in-process `SpanCollector` keeps finished spans grouped by
`execution.id`, enabling `GET /api/executions/{id}/traces` for UI inspection.

Optional OTLP export is enabled if the environment sets
`OTEL_EXPORTER_OTLP_ENDPOINT` — no code change needed.
"""
from __future__ import annotations

import logging
import os
import threading
from collections import defaultdict, deque
from typing import Any

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

logger = logging.getLogger(__name__)

_SERVICE_NAME = "agentic-orchestrator"
_MAX_SPANS_PER_EXEC = 500


class SpanCollector(SpanProcessor):
    """Keeps finished spans grouped by the `execution.id` attribute."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._by_exec: dict[str, deque[dict[str, Any]]] = defaultdict(
            lambda: deque(maxlen=_MAX_SPANS_PER_EXEC)
        )

    def on_start(self, span: ReadableSpan, parent_context=None) -> None:  # noqa: ARG002
        return

    def on_end(self, span: ReadableSpan) -> None:
        attrs = dict(span.attributes or {})
        exec_id = attrs.get("execution.id")
        if not exec_id:
            return
        record = {
            "name": span.name,
            "span_id": format(span.context.span_id, "016x"),
            "trace_id": format(span.context.trace_id, "032x"),
            "parent_span_id": (
                format(span.parent.span_id, "016x") if span.parent else None
            ),
            "start_ns": span.start_time,
            "end_ns": span.end_time,
            "duration_ms": (
                (span.end_time - span.start_time) / 1_000_000
                if span.start_time and span.end_time
                else None
            ),
            "status": span.status.status_code.name if span.status else "UNSET",
            "attributes": attrs,
            "events": [
                {
                    "name": e.name,
                    "ts_ns": e.timestamp,
                    "attributes": dict(e.attributes or {}),
                }
                for e in (span.events or [])
            ],
        }
        with self._lock:
            self._by_exec[exec_id].append(record)

    def shutdown(self) -> None:
        return

    def force_flush(self, timeout_millis: int = 30_000) -> bool:  # noqa: ARG002
        return True

    def get_spans(self, exec_id: str) -> list[dict[str, Any]]:
        with self._lock:
            return list(self._by_exec.get(exec_id, ()))


_collector: SpanCollector | None = None
_tracer: trace.Tracer | None = None


def init_tracing() -> None:
    """Idempotent. Safe to call multiple times."""
    global _collector, _tracer
    if _tracer is not None:
        return

    resource = Resource.create({"service.name": _SERVICE_NAME})
    provider = TracerProvider(resource=resource)

    _collector = SpanCollector()
    provider.add_span_processor(_collector)

    # Optional OTLP exporter — enabled only if endpoint is configured.
    otlp_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if otlp_endpoint:
        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter,
            )

            provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
            logger.info("OTLP exporter enabled at %s", otlp_endpoint)
        except Exception as exc:  # noqa: BLE001
            logger.warning("OTLP exporter not available: %s", exc)

    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer(_SERVICE_NAME)


def tracer() -> trace.Tracer:
    if _tracer is None:
        init_tracing()
    return _tracer  # type: ignore[return-value]


def get_spans(exec_id: str) -> list[dict[str, Any]]:
    if _collector is None:
        return []
    return _collector.get_spans(exec_id)
