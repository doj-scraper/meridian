"""Workflow loader + DevOps reference workflow seed."""
from __future__ import annotations

import json
from pathlib import Path

from persistence.models import WorkflowSpec

_WF_DIR = Path(__file__).parent


def load_workflow_file(filename: str) -> WorkflowSpec:
    with (_WF_DIR / filename).open() as f:
        data = json.load(f)
    return WorkflowSpec(**data)


def load_devops() -> WorkflowSpec:
    return load_workflow_file("devops_pipeline.json")
