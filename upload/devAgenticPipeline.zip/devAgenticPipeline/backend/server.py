"""FastAPI entrypoint: REST API + WebSocket streaming.

Routes are namespaced under /api to satisfy platform ingress.
"""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import agents.builtin as builtin_agents
import policies.registry as policies_registry
from engine import orchestrator
from engine.circuit_breaker import registry as cb_registry
from engine.tracing import get_spans, init_tracing
from persistence import repository as repo
from persistence.models import ExecutionStatus, WorkflowSpec
from transport.ws_manager import bus
from workflows.loader import load_devops

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("orchestrator")


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ARG001
    init_tracing()
    builtin_agents.register_builtins()
    policies_registry.register_builtins()
    await repo.init_indexes()
    # Seed canonical DevOps workflow (idempotent upsert)
    wf = load_devops()
    await repo.upsert_workflow(wf)
    logger.info("Seeded workflow: %s v%s", wf.slug, wf.version)
    yield


app = FastAPI(title="Agentic Orchestrator", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------
class StartExecutionReq(BaseModel):
    workflow_slug: str = "devops_pipeline"
    workflow_version: int | None = None
    chaos_mode: bool = False
    policy_override: str | None = None  # "human" | "probabilistic" | "llm" | "rule"


class DecideReq(BaseModel):
    action_id: str


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/api/health")
async def health() -> dict:
    return {"status": "ok", "service": "agentic-orchestrator"}


# ---------------------------------------------------------------------------
# Workflows
# ---------------------------------------------------------------------------
@app.get("/api/workflows")
async def list_workflows():
    return [wf.model_dump(by_alias=True, mode="json") for wf in await repo.list_workflows()]


@app.get("/api/workflows/{slug}")
async def get_workflow(slug: str, version: int | None = None):
    wf = await repo.get_workflow_by_slug(slug, version)
    if not wf:
        raise HTTPException(404, f"Workflow '{slug}' not found")
    return wf.model_dump(by_alias=True, mode="json")


@app.post("/api/workflows")
async def create_workflow(wf: WorkflowSpec):
    await repo.upsert_workflow(wf)
    return wf.model_dump(by_alias=True, mode="json")


# ---------------------------------------------------------------------------
# Executions
# ---------------------------------------------------------------------------
@app.post("/api/executions")
async def start_execution(req: StartExecutionReq):
    wf = await repo.get_workflow_by_slug(req.workflow_slug, req.workflow_version)
    if not wf:
        raise HTTPException(404, f"Workflow '{req.workflow_slug}' not found")
    state = await orchestrator.start_execution(
        wf, chaos_mode=req.chaos_mode, policy_override=req.policy_override
    )
    return state.model_dump(mode="json")


@app.get("/api/executions")
async def list_executions(limit: int = 25):
    return [s.model_dump(mode="json") for s in await repo.list_executions(limit=limit)]


@app.get("/api/executions/{exec_id}")
async def get_execution(exec_id: str):
    state = await repo.get_execution(exec_id)
    if not state:
        raise HTTPException(404, "Execution not found")
    return state.model_dump(mode="json")


@app.get("/api/executions/{exec_id}/events")
async def get_events(exec_id: str, from_seq: int = 0):
    events = await repo.list_events(exec_id, from_seq=from_seq)
    return [e.model_dump(mode="json") for e in events]


@app.get("/api/executions/{exec_id}/traces")
async def get_traces(exec_id: str):
    """Return finished OpenTelemetry spans for this execution (in-memory store)."""
    state = await repo.get_execution(exec_id)
    if not state:
        raise HTTPException(404, "Execution not found")
    return {"execution_id": exec_id, "spans": get_spans(exec_id)}


@app.get("/api/circuit-breakers")
async def list_breakers():
    """Snapshot of all active circuit breakers (handler key, state, window stats)."""
    return {"breakers": cb_registry.all()}


@app.post("/api/executions/{exec_id}/decide")
async def decide(exec_id: str, body: DecideReq):
    state = await repo.get_execution(exec_id)
    if not state:
        raise HTTPException(404, "Execution not found")
    if state.status != ExecutionStatus.AWAITING_DECISION:
        raise HTTPException(409, f"Execution not awaiting decision (status={state.status.value})")
    await orchestrator.submit_decision(exec_id, body.action_id)
    return {"ok": True}


@app.post("/api/executions/{exec_id}/pause")
async def pause(exec_id: str):
    state = await repo.get_execution(exec_id)
    if not state:
        raise HTTPException(404, "Execution not found")
    await orchestrator.pause_execution(exec_id)
    return {"ok": True}


@app.post("/api/executions/{exec_id}/resume")
async def resume(exec_id: str):
    state = await repo.get_execution(exec_id)
    if not state:
        raise HTTPException(404, "Execution not found")
    await orchestrator.resume_execution(exec_id)
    return {"ok": True}


# ---------------------------------------------------------------------------
# WebSocket: real-time event streaming with replay
# ---------------------------------------------------------------------------
@app.websocket("/api/ws/executions/{exec_id}")
async def ws_execution(websocket: WebSocket, exec_id: str, from_seq: int = Query(0)):
    await websocket.accept()
    queue = await bus.subscribe(exec_id)
    try:
        # 1) Replay historical events (from_seq)
        state = await repo.get_execution(exec_id)
        if state is None:
            await websocket.send_json({"type": "_error", "message": "execution not found"})
            await websocket.close()
            return

        await websocket.send_json({"type": "_hello", "execution": state.model_dump(mode="json")})
        history = await repo.list_events(exec_id, from_seq=from_seq)
        for e in history:
            await websocket.send_json({"type": "event", "event": e.model_dump(mode="json")})
        await websocket.send_json({"type": "_replay_done", "seq": state.seq})

        last_seq = history[-1].seq if history else from_seq

        # 2) Live stream (drop dupes <= last_seq)
        while True:
            try:
                evt = await asyncio.wait_for(queue.get(), timeout=30.0)
            except asyncio.TimeoutError:
                await websocket.send_json({"type": "_ping"})
                continue
            if evt.seq <= last_seq:
                continue
            last_seq = evt.seq
            await websocket.send_json({"type": "event", "event": evt.model_dump(mode="json")})
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # noqa: BLE001
        logger.exception("WS error: %s", exc)
    finally:
        await bus.unsubscribe(exec_id, queue)
