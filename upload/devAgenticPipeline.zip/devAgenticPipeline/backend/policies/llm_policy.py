"""LLM-driven decision policy via Emergent Universal Key.

Builds a strict-JSON prompt from node intent, shared context, and recent
events. Validates allowed actions. Low confidence -> needs_human=True.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from typing import Any

from emergentintegrations.llm.chat import LlmChat, UserMessage

from persistence.models import EdgeSpec, NodeSpec

from .base import Policy, PolicyDecision

logger = logging.getLogger(__name__)

_SYSTEM = (
    "You are a deterministic policy engine for an agentic workflow orchestrator. "
    "Given a decision node's intent, the shared workflow context, and recent events, "
    "choose EXACTLY ONE allowed action. Respond with STRICT JSON only, no prose:\n"
    '{"decision": "<action_id>", "confidence": <float 0..1>, "reasoning": "<short>"}. '
    "The action MUST be one of the allowed_actions. If uncertain, set confidence below 0.5."
)


def _extract_json(text: str) -> dict[str, Any] | None:
    text = text.strip()
    # Strip code fences if present
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    # Find first {...} block
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        return json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None


class LlmPolicy(Policy):
    name = "llm"

    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        cfg = node.policy
        if cfg is None:
            return PolicyDecision(needs_human=True, source="llm", reasoning="No policy config")

        allowed_actions = []
        for e in outgoing_edges:
            aid = e.action_id or f"{e.from_}->{e.to}"
            allowed_actions.append({
                "action_id": aid,
                "label": e.label or aid,
                "severity": e.severity,
                "narrative_hint": e.narrative or "",
            })

        prompt = {
            "node": {"id": node.id, "name": node.name, "intent": node.intent or ""},
            "allowed_actions": allowed_actions,
            "context_snapshot": {k: v for k, v in context.items() if not k.startswith("_")},
            "recent_events": recent_events[-8:],
        }

        api_key = os.environ.get("EMERGENT_LLM_KEY")
        if not api_key:
            logger.warning("EMERGENT_LLM_KEY missing; LLM policy falls back to human")
            return PolicyDecision(needs_human=True, source="llm", reasoning="No LLM key")

        try:
            chat = LlmChat(
                api_key=api_key,
                session_id=f"policy-{node.id}-{uuid.uuid4().hex[:8]}",
                system_message=_SYSTEM,
            ).with_model(cfg.llm_provider, cfg.llm_model)
            resp = await chat.send_message(UserMessage(text=json.dumps(prompt)))
        except Exception as exc:  # noqa: BLE001
            logger.exception("LLM policy call failed: %s", exc)
            return PolicyDecision(needs_human=True, source="llm", reasoning=f"LLM error: {exc}")

        parsed = _extract_json(resp if isinstance(resp, str) else str(resp))
        if not parsed:
            return PolicyDecision(needs_human=True, source="llm", reasoning="Unparseable LLM response")

        decision = parsed.get("decision")
        confidence = float(parsed.get("confidence", 0.0))
        reasoning = str(parsed.get("reasoning", ""))[:500]

        allowed_ids = {a["action_id"] for a in allowed_actions}
        if decision not in allowed_ids:
            return PolicyDecision(
                needs_human=True,
                source="llm",
                reasoning=f"LLM chose disallowed action '{decision}'",
            )
        if confidence < cfg.min_confidence:
            return PolicyDecision(
                needs_human=True,
                action_id=decision,
                confidence=confidence,
                reasoning=f"Low confidence ({confidence:.2f}): {reasoning}",
                source="llm",
            )

        return PolicyDecision(
            action_id=decision,
            confidence=confidence,
            reasoning=reasoning,
            source="llm",
        )
