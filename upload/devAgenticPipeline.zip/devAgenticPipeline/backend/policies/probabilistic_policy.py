"""Probabilistic policy — weighted random choice over outgoing edges.

Uses each edge's `probability` if set, else uniform. Preserves the original
chaos-mode branching behaviour of the legacy engine.
"""
from __future__ import annotations

import random
from typing import Any

from persistence.models import EdgeSpec, NodeSpec

from .base import Policy, PolicyDecision


class ProbabilisticPolicy(Policy):
    name = "probabilistic"

    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        if not outgoing_edges:
            return PolicyDecision(needs_human=True, source="probabilistic", reasoning="No edges")

        weights = [e.probability if e.probability is not None else 1.0 for e in outgoing_edges]
        total = sum(weights)
        if total <= 0:
            chosen = random.choice(outgoing_edges)
        else:
            r = random.random() * total
            acc = 0.0
            chosen = outgoing_edges[-1]
            for edge, w in zip(outgoing_edges, weights):
                acc += w
                if r <= acc:
                    chosen = edge
                    break

        action_id = chosen.action_id or f"{chosen.from_}->{chosen.to}"
        return PolicyDecision(
            action_id=action_id,
            confidence=0.75,
            reasoning=f"Probabilistic pick over {len(outgoing_edges)} edges",
            source="probabilistic",
        )
