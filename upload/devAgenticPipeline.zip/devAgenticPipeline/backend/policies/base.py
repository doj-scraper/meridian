"""Policy abstraction — pluggable decision strategy for decision nodes.

Returns a PolicyDecision with either a chosen action_id, or `needs_human=True`
when confidence is low / invalid / explicitly human-gated.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from persistence.models import EdgeSpec, NodeSpec


@dataclass
class PolicyDecision:
    action_id: str | None = None
    confidence: float = 0.0
    reasoning: str = ""
    needs_human: bool = False
    source: str = "unknown"  # rule | probabilistic | llm | human


class Policy:
    name: str = "base"

    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        raise NotImplementedError


# Registry of decision policies
_registry: dict[str, Policy] = {}


def register(name: str, policy: Policy) -> None:
    _registry[name] = policy


def get(name: str) -> Policy:
    if name not in _registry:
        raise KeyError(f"No policy registered for '{name}'")
    return _registry[name]
