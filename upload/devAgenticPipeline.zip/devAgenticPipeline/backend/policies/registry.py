"""Policy registry bootstrap."""
from __future__ import annotations

from .base import get, register  # re-export
from .human_policy import HumanPolicy
from .llm_policy import LlmPolicy
from .probabilistic_policy import ProbabilisticPolicy
from .rule_policy import RulePolicy


def register_builtins() -> None:
    register("human", HumanPolicy())
    register("rule", RulePolicy())
    register("probabilistic", ProbabilisticPolicy())
    register("llm", LlmPolicy())


__all__ = ["register_builtins", "get", "register"]
