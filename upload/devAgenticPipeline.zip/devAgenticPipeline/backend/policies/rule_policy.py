"""Rule-based policy — picks an edge based on declarative conditions.

Each rule: {"when": {"context_key": "value", ...}, "action_id": "retry"}
First matching rule wins; if none match, returns needs_human=True.
"""
from __future__ import annotations

from typing import Any

from persistence.models import EdgeSpec, NodeSpec

from .base import Policy, PolicyDecision


def _matches(when: dict[str, Any], context: dict[str, Any]) -> bool:
    for key, expected in when.items():
        if context.get(key) != expected:
            return False
    return True


class RulePolicy(Policy):
    name = "rule"

    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        rules = node.policy.rules if node.policy else []
        for rule in rules:
            if _matches(rule.get("when", {}), context):
                return PolicyDecision(
                    action_id=rule["action_id"],
                    confidence=1.0,
                    reasoning=f"Matched rule: {rule.get('when', {})}",
                    source="rule",
                )
        return PolicyDecision(
            needs_human=True,
            source="rule",
            reasoning="No rule matched; falling back to human",
        )
