"""Human-in-the-loop policy — always defers to UI via decision_required event."""
from __future__ import annotations

from typing import Any

from persistence.models import EdgeSpec, NodeSpec

from .base import Policy, PolicyDecision


class HumanPolicy(Policy):
    name = "human"

    async def decide(
        self,
        node: NodeSpec,
        outgoing_edges: list[EdgeSpec],
        context: dict[str, Any],
        recent_events: list[dict[str, Any]],
    ) -> PolicyDecision:
        return PolicyDecision(needs_human=True, source="human", reasoning="Human intervention required")
