"""MongoDB repository with optimistic concurrency + event sourcing.

Collections:
    workflows  - versioned workflow definitions
    executions - execution state (optimistic locking via `version`)
    events     - append-only event log keyed by (execution_id, seq)
"""
from __future__ import annotations

import os
from typing import Any

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

from .models import (
    Event,
    ExecutionState,
    ExecutionStatus,
    WorkflowSpec,
)

_client: AsyncIOMotorClient | None = None
_db: AsyncIOMotorDatabase | None = None


def get_db() -> AsyncIOMotorDatabase:
    global _client, _db
    if _db is None:
        mongo_url = os.environ["MONGO_URL"]
        db_name = os.environ["DB_NAME"]
        _client = AsyncIOMotorClient(mongo_url)
        _db = _client[db_name]
    return _db


async def init_indexes() -> None:
    db = get_db()
    await db.workflows.create_index("slug")
    await db.workflows.create_index([("slug", 1), ("version", -1)])
    await db.executions.create_index("id", unique=True)
    await db.executions.create_index("workflow_id")
    await db.executions.create_index("status")
    await db.events.create_index([("execution_id", 1), ("seq", 1)], unique=True)


def _strip_id(doc: dict[str, Any] | None) -> dict[str, Any] | None:
    if doc is None:
        return None
    doc.pop("_id", None)
    return doc


class ConcurrencyError(RuntimeError):
    """Raised when optimistic concurrency check fails."""


# --- Workflows -------------------------------------------------------------
async def upsert_workflow(wf: WorkflowSpec) -> WorkflowSpec:
    db = get_db()
    doc = wf.model_dump(by_alias=True, mode="json")
    await db.workflows.update_one(
        {"slug": wf.slug, "version": wf.version},
        {"$set": doc},
        upsert=True,
    )
    return wf


async def get_workflow(workflow_id: str) -> WorkflowSpec | None:
    db = get_db()
    doc = await db.workflows.find_one({"id": workflow_id}, {"_id": 0})
    return WorkflowSpec(**doc) if doc else None


async def get_workflow_by_slug(slug: str, version: int | None = None) -> WorkflowSpec | None:
    db = get_db()
    q: dict[str, Any] = {"slug": slug}
    if version is not None:
        q["version"] = version
    doc = await db.workflows.find_one(q, {"_id": 0}, sort=[("version", -1)])
    return WorkflowSpec(**doc) if doc else None


async def list_workflows() -> list[WorkflowSpec]:
    db = get_db()
    cursor = db.workflows.find({}, {"_id": 0}).sort("slug", 1)
    return [WorkflowSpec(**d) async for d in cursor]


# --- Executions ------------------------------------------------------------
async def create_execution(state: ExecutionState) -> ExecutionState:
    db = get_db()
    await db.executions.insert_one(state.model_dump(mode="json"))
    return state


async def get_execution(exec_id: str) -> ExecutionState | None:
    db = get_db()
    doc = await db.executions.find_one({"id": exec_id}, {"_id": 0})
    return ExecutionState(**doc) if doc else None


async def list_executions(limit: int = 25) -> list[ExecutionState]:
    db = get_db()
    cursor = db.executions.find({}, {"_id": 0}).sort("started_at", -1).limit(limit)
    return [ExecutionState(**d) async for d in cursor]


async def save_execution(state: ExecutionState) -> ExecutionState:
    """Optimistic concurrency: match on (id, version), then bump version."""
    db = get_db()
    expected_version = state.version
    state.version = expected_version + 1
    result = await db.executions.update_one(
        {"id": state.id, "version": expected_version},
        {"$set": state.model_dump(mode="json")},
    )
    if result.matched_count == 0:
        raise ConcurrencyError(
            f"Execution {state.id} version mismatch (expected {expected_version})"
        )
    return state


async def set_status(exec_id: str, status: ExecutionStatus) -> None:
    """Unconditional status update (used by pause/resume control path)."""
    db = get_db()
    await db.executions.update_one(
        {"id": exec_id},
        {"$set": {"status": status.value}, "$inc": {"version": 1}},
    )


# --- Events ----------------------------------------------------------------
async def append_event(evt: Event) -> Event:
    db = get_db()
    await db.events.insert_one(evt.model_dump(mode="json"))
    return evt


async def list_events(exec_id: str, from_seq: int = 0) -> list[Event]:
    db = get_db()
    cursor = (
        db.events.find({"execution_id": exec_id, "seq": {"$gte": from_seq}}, {"_id": 0})
        .sort("seq", 1)
    )
    return [Event(**d) async for d in cursor]
