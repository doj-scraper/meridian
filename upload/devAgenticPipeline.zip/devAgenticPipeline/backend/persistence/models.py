"""Pydantic domain models for workflows, executions, events.

All models are BSON-safe (no ObjectId leaks). Mongo `_id` is never exposed.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


def _uuid() -> str:
    return str(uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Workflow definition
# ---------------------------------------------------------------------------
class RetryPolicy(BaseModel):
    max_attempts: int = 1
    base_backoff_s: float = 0.2
    max_backoff_s: float = 5.0


class CircuitBreakerConfig(BaseModel):
    """Per-handler (or per-node) circuit breaker configuration."""
    enabled: bool = True
    # Grouping key for shared circuits. If unset, defaults to the node handler.
    key: str | None = None
    failure_threshold: int = 5
    window_s: float = 60.0
    open_duration_s: float = 30.0


class PolicyConfig(BaseModel):
    """How a decision node decides. Pluggable strategies."""
    mode: Literal["human", "rule", "probabilistic", "llm"] = "human"
    llm_model: str = "claude-sonnet-4-5-20250929"
    llm_provider: str = "anthropic"
    temperature: float = 0.2
    rules: list[dict[str, Any]] = Field(default_factory=list)
    min_confidence: float = 0.5


class NodeSpec(BaseModel):
    id: str
    name: str
    phase: str
    role: Literal["entry", "process", "exit", "gate", "recovery"]
    type: Literal["action", "decision", "terminal"]
    icon: str = "commit"
    handler: str = "simulate"
    intent: str | None = None
    retry_policy: RetryPolicy = Field(default_factory=RetryPolicy)
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)
    timeout_s: float = 10.0
    # For chaos/probabilistic failure injection on action nodes
    failure_probability: float = 0.0
    # Compensation node id to run on rollback
    compensation: str | None = None
    # Decision only
    policy: PolicyConfig | None = None


class EdgeSpec(BaseModel):
    from_: str = Field(alias="from")
    to: str
    # action_id identifies this edge for decision nodes
    action_id: str | None = None
    label: str | None = None
    narrative: str | None = None
    severity: Literal["clean", "warning", "critical"] = "clean"
    # "success" | "failure" for action nodes; None = default
    condition: str | None = None
    probability: float | None = None

    model_config = ConfigDict(populate_by_name=True)


class PhaseSpec(BaseModel):
    id: str
    name: str
    order: int


class WorkflowSpec(BaseModel):
    id: str = Field(default_factory=_uuid)
    slug: str
    name: str
    version: int = 1
    description: str = ""
    phases: list[PhaseSpec] = Field(default_factory=list)
    nodes: list[NodeSpec]
    edges: list[EdgeSpec]
    entry_node_id: str
    created_at: datetime = Field(default_factory=_now)


# ---------------------------------------------------------------------------
# Execution state
# ---------------------------------------------------------------------------
class ExecutionStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    AWAITING_DECISION = "awaiting_decision"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


class ExecutionState(BaseModel):
    id: str = Field(default_factory=_uuid)
    workflow_id: str
    workflow_slug: str
    workflow_version: int
    status: ExecutionStatus = ExecutionStatus.PENDING
    current_node_id: str | None = None
    pending_decision_node_id: str | None = None
    version: int = 0  # optimistic concurrency
    seq: int = 0      # monotonically increasing event sequence
    context: dict[str, Any] = Field(default_factory=dict)
    phase_memory: dict[str, str] = Field(default_factory=dict)  # phase -> severity
    node_attempts: dict[str, int] = Field(default_factory=dict)
    node_results: dict[str, Any] = Field(default_factory=dict)  # idempotency cache
    chaos_mode: bool = False
    policy_override: str | None = None  # force "human" | "llm" | ...
    started_at: datetime = Field(default_factory=_now)
    finished_at: datetime | None = None
    last_error: str | None = None


# ---------------------------------------------------------------------------
# Events (event sourcing)
# ---------------------------------------------------------------------------
class EventType(str, Enum):
    EXECUTION_STARTED = "execution_started"
    NODE_STARTED = "node_started"
    NODE_COMPLETED = "node_completed"
    NODE_FAILED = "node_failed"
    NODE_RETRY = "node_retry"
    DECISION_REQUIRED = "decision_required"
    DECISION_MADE = "decision_made"
    EDGE_TRAVERSED = "edge_traversed"
    PHASE_ENTERED = "phase_entered"
    PHASE_COMPLETED = "phase_completed"
    COMPENSATION_TRIGGERED = "compensation_triggered"
    CIRCUIT_OPENED = "circuit_opened"
    CIRCUIT_HALF_OPEN = "circuit_half_open"
    CIRCUIT_CLOSED = "circuit_closed"
    CIRCUIT_SHORT_CIRCUITED = "circuit_short_circuited"
    EXECUTION_PAUSED = "execution_paused"
    EXECUTION_RESUMED = "execution_resumed"
    WORKFLOW_COMPLETED = "workflow_completed"
    WORKFLOW_FAILED = "workflow_failed"


class Event(BaseModel):
    id: str = Field(default_factory=_uuid)
    execution_id: str
    seq: int
    type: EventType
    severity: Literal["clean", "warning", "critical", "info"] = "info"
    description: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    ts: datetime = Field(default_factory=_now)
