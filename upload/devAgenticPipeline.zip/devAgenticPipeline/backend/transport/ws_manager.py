"""In-process pub/sub for WebSocket fan-out.

Clients subscribe to an execution_id. Engine publishes Event objects.
Replay from a given sequence is read from Mongo by the websocket handler.
"""
from __future__ import annotations

import asyncio
from collections import defaultdict

from persistence.models import Event


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, set[asyncio.Queue]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def subscribe(self, execution_id: str) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=1000)
        async with self._lock:
            self._subscribers[execution_id].add(q)
        return q

    async def unsubscribe(self, execution_id: str, q: asyncio.Queue) -> None:
        async with self._lock:
            self._subscribers[execution_id].discard(q)
            if not self._subscribers[execution_id]:
                self._subscribers.pop(execution_id, None)

    async def publish(self, event: Event) -> None:
        subs = list(self._subscribers.get(event.execution_id, ()))
        for q in subs:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                # Drop for slow consumer; they can reconnect with replay.
                pass


bus = EventBus()
