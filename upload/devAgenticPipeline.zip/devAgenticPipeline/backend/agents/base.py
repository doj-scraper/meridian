"""Agent abstraction base classes.

An Agent is a pluggable unit of execution tied to a NodeSpec. It receives
the shared `context`, performs async work (local function / API call / LLM),
returns a structured AgentResult, and emits no side-effects besides its return.

All event emission and persistence is owned by the orchestrator.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

from persistence.models import NodeSpec


@dataclass
class AgentResult:
    status: Literal["success", "failure"] = "success"
    outputs: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    # For action nodes with a "failure" condition branch
    condition: str | None = None


class Agent:
    """Base class. Subclasses implement `run`."""

    name: str = "base"

    async def run(self, node: NodeSpec, context: dict[str, Any]) -> AgentResult:
        raise NotImplementedError


# ---- Registry --------------------------------------------------------------
_registry: dict[str, Agent] = {}


def register(handler_name: str, agent: Agent) -> None:
    _registry[handler_name] = agent


def get(handler_name: str) -> Agent:
    if handler_name not in _registry:
        raise KeyError(f"No agent registered for handler '{handler_name}'")
    return _registry[handler_name]


def register_callable(handler_name: str) -> Callable[[type[Agent]], type[Agent]]:
    def deco(cls: type[Agent]) -> type[Agent]:
        register(handler_name, cls())
        return cls
    return deco
