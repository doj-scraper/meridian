"""Built-in agents used by the DevOps reference workflow.

Each agent is a pluggable handler. Adding a new handler = subclass Agent +
register(). The engine does not know about specific handlers.
"""
from __future__ import annotations

import asyncio
import random
from typing import Any

from persistence.models import NodeSpec

from .base import Agent, AgentResult, register


class SimulatedAction(Agent):
    """Generic simulated work unit with small async sleep + probabilistic failure."""

    name = "simulate"

    async def run(self, node: NodeSpec, context: dict[str, Any]) -> AgentResult:
        await asyncio.sleep(random.uniform(0.15, 0.45))

        chaos = bool(context.get("_chaos_mode"))
        if chaos and node.failure_probability > 0 and random.random() < node.failure_probability:
            return AgentResult(
                status="failure",
                condition="failure",
                error=f"Simulated failure at {node.name}",
                outputs={"attempted_at": node.id},
            )

        # Normal success, carries forward a breadcrumb in context
        return AgentResult(
            status="success",
            condition="success",
            outputs={"node": node.id, "phase": node.phase, "at": node.name},
        )


class Terminal(Agent):
    """Terminal node: no outgoing work; orchestrator interprets as completion."""

    name = "terminal"

    async def run(self, node: NodeSpec, context: dict[str, Any]) -> AgentResult:
        return AgentResult(status="success", outputs={"terminal": node.id})


class DecisionGate(Agent):
    """Decision nodes are resolved by the orchestrator's policy layer.

    This agent just marks the node as reached. The orchestrator inspects the
    node's `policy` and invokes the appropriate policy engine.
    """

    name = "decision"

    async def run(self, node: NodeSpec, context: dict[str, Any]) -> AgentResult:
        return AgentResult(status="success", outputs={"awaiting_policy": node.id})


def register_builtins() -> None:
    register("simulate", SimulatedAction())
    register("terminal", Terminal())
    register("decision", DecisionGate())
