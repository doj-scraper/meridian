/* PipelineStudio — read-only UI renderer for the agentic orchestrator.
   - Fetches workflow definition (nodes + edges + phases) from /api/workflows
   - Starts an execution, subscribes to /api/ws/executions/<id>
   - Renders lanes, nodes, connectors, artifact memory, narrative strip
   - Shows decision panel when `decision_required` event is received
*/
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { api, EventStream } from '../lib/orchestratorClient';
import { Icon } from './Icons';

const SEVERITY_RANK = { clean: 0, warning: 1, critical: 2 };

function bumpMemory(current, severity) {
  const a = SEVERITY_RANK[current] ?? 0;
  const b = SEVERITY_RANK[severity] ?? 0;
  return b > a ? severity : current;
}

export default function PipelineStudio() {
  const [workflow, setWorkflow] = useState(null);
  const [execId, setExecId] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | running | completed | failed | awaiting_decision | paused
  const [connState, setConnState] = useState('disconnected');

  // Derived rendering state (driven entirely by events)
  const [nodeStates, setNodeStates] = useState({}); // nodeId -> 'active'|'success'|'warning'|'failure'|'decision-active'
  const [activeEdges, setActiveEdges] = useState({}); // "from->to" -> severity
  const [phaseMemory, setPhaseMemory] = useState({}); // phase -> severity
  const [activePhase, setActivePhase] = useState(null);
  const [narrative, setNarrative] = useState([]); // [{text, severity}]
  const [pendingDecision, setPendingDecision] = useState(null); // {nodeId, intent, options, policyHint}
  const [chaosMode, setChaosMode] = useState(false);
  const [policyOverride, setPolicyOverride] = useState('human');
  const [phaseTimers, setPhaseTimers] = useState({}); // phase -> seconds
  const [events, setEvents] = useState([]); // full event log (inspector)
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState('events'); // 'events' | 'traces' | 'circuits'
  const [traces, setTraces] = useState([]);
  const [breakers, setBreakers] = useState([]);
  const [systemLocked, setSystemLocked] = useState(false);
  const [finalOutcome, setFinalOutcome] = useState(null);

  const streamRef = useRef(null);
  const stageRef = useRef(null);
  const connectorSvgRef = useRef(null);
  const activePhaseStartRef = useRef({}); // phase -> ts

  // Fetch workflow on mount
  useEffect(() => {
    api.getWorkflow('devops_pipeline')
      .then(setWorkflow)
      .catch((e) => console.error('load workflow', e));
  }, []);

  // Phase timer tick
  useEffect(() => {
    if (!activePhase || systemLocked) return undefined;
    const iv = setInterval(() => {
      setPhaseTimers((t) => {
        const start = activePhaseStartRef.current[activePhase] || Date.now();
        return { ...t, [activePhase]: (Date.now() - start) / 1000 };
      });
    }, 100);
    return () => clearInterval(iv);
  }, [activePhase, systemLocked]);

  // Render connectors on layout / resize / workflow load
  const renderConnectors = useCallback(() => {
    if (!workflow || !stageRef.current || !connectorSvgRef.current) return;
    const svg = connectorSvgRef.current;
    svg.innerHTML = '';
    const stageRect = stageRef.current.getBoundingClientRect();

    workflow.edges.forEach((edge) => {
      const from = edge.from;
      const to = edge.to;
      const n1 = document.getElementById(`node-${from}`);
      const n2 = document.getElementById(`node-${to}`);
      if (!n1 || !n2) return;
      const r1 = n1.getBoundingClientRect();
      const r2 = n2.getBoundingClientRect();
      const scrollLeft = stageRef.current.scrollLeft;
      const x1 = r1.left + r1.width / 2 - stageRect.left + scrollLeft;
      const y1 = r1.top + r1.height / 2 - stageRect.top;
      const x2 = r2.left + r2.width / 2 - stageRect.left + scrollLeft;
      const y2 = r2.top + r2.height / 2 - stageRect.top;

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.classList.add('conn-path');
      path.id = `conn-${from}-${to}`;

      const fromNode = workflow.nodes.find((n) => n.id === from);
      const toNode = workflow.nodes.find((n) => n.id === to);
      if (fromNode && toNode && fromNode.phase !== toNode.phase) path.classList.add('handoff');
      if (fromNode && toNode && fromNode.phase === toNode.phase && x2 < x1) path.classList.add('loop');

      const key = `${from}->${to}`;
      const sev = activeEdges[key];
      if (sev) {
        path.classList.add('active');
        if (sev === 'warning') path.classList.add('warning');
        if (sev === 'critical') path.classList.add('critical');
      }

      const dx = Math.abs(x2 - x1);
      const d =
        dx < 30
          ? `M${x1},${y1} C${x1 + 60},${y1} ${x1 + 60},${y2} ${x2},${y2}`
          : `M${x1},${y1} C${x1 + dx / 2},${y1} ${x2 - dx / 2},${y2} ${x2},${y2}`;
      path.setAttribute('d', d);
      svg.appendChild(path);
    });
  }, [workflow, activeEdges]);

  useLayoutEffect(() => {
    renderConnectors();
  }, [renderConnectors, nodeStates]);

  useEffect(() => {
    const onResize = () => renderConnectors();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [renderConnectors]);

  // Event handler
  const applyEvent = useCallback((e) => {
    setEvents((prev) => [...prev, e]);
    const { type, payload = {}, severity, description } = e;

    if (type === 'execution_started') {
      setStatus('running');
      setSystemLocked(false);
    }
    if (type === 'phase_entered') {
      const p = payload.phase;
      setActivePhase(p);
      if (!activePhaseStartRef.current[p]) activePhaseStartRef.current[p] = Date.now();
      setPhaseMemory((m) => ({ ...m, [p]: m[p] || 'clean' }));
    }
    if (type === 'phase_completed') {
      const p = payload.phase;
      const sev = payload.memory || 'clean';
      setPhaseMemory((m) => ({ ...m, [p]: bumpMemory(m[p] || 'clean', sev) }));
    }
    if (type === 'node_started') {
      const id = payload.node_id;
      setNodeStates((s) => ({ ...s, [id]: 'active' }));
    }
    if (type === 'node_completed') {
      const id = payload.node_id;
      setNodeStates((s) => ({ ...s, [id]: s[id] === 'warning' ? 'warning' : 'success' }));
    }
    if (type === 'node_retry') {
      const id = payload.node_id;
      setNodeStates((s) => ({ ...s, [id]: 'warning' }));
    }
    if (type === 'node_failed') {
      const id = payload.node_id;
      setNodeStates((s) => ({ ...s, [id]: 'failure' }));
    }
    if (type === 'edge_traversed') {
      const key = `${payload.from}->${payload.to}`;
      const sev = payload.severity || 'clean';
      setActiveEdges((m) => ({ ...m, [key]: sev }));
      if (payload.narrative || description) {
        setNarrative((n) => [...n, { text: payload.narrative || description, severity: sev }]);
      }
      // phase memory bump by edge severity on source's phase
      if (workflow) {
        const src = workflow.nodes.find((n) => n.id === payload.from);
        if (src) setPhaseMemory((m) => ({ ...m, [src.phase]: bumpMemory(m[src.phase] || 'clean', sev) }));
      }
    }
    if (type === 'decision_required') {
      const id = payload.node_id;
      setNodeStates((s) => ({ ...s, [id]: 'decision-active' }));
      setStatus('awaiting_decision');
      setPendingDecision({
        nodeId: id,
        intent: payload.intent,
        options: payload.options || [],
        policyHint: payload.policy_hint,
      });
    }
    if (type === 'decision_made') {
      const id = payload.node_id;
      setPendingDecision(null);
      setStatus('running');
      // restore node appearance
      setNodeStates((s) => ({
        ...s,
        [id]: severity === 'critical' ? 'failure' : severity === 'warning' ? 'warning' : 'success',
      }));
      setNarrative((n) => [...n, { text: description, severity: severity === 'info' ? 'clean' : severity }]);
    }
    if (type === 'execution_paused') {
      setStatus('paused');
    }
    if (type === 'execution_resumed') {
      setStatus('running');
    }
    if (type === 'workflow_completed') {
      setStatus('completed');
      setSystemLocked(true);
      setFinalOutcome('completed');
    }
    if (type === 'workflow_failed') {
      setStatus('failed');
      setSystemLocked(true);
      setFinalOutcome('failed');
    }
    if (type === 'compensation_triggered') {
      setNarrative((n) => [...n, { text: description, severity: 'warning' }]);
    }
    if (type === 'circuit_opened' || type === 'circuit_short_circuited') {
      setNarrative((n) => [...n, { text: description, severity: 'critical' }]);
    }
    if (type === 'circuit_closed') {
      setNarrative((n) => [...n, { text: description, severity: 'clean' }]);
    }
  }, [workflow]);

  const resetUi = useCallback(() => {
    setNodeStates({});
    setActiveEdges({});
    setPhaseMemory({});
    setActivePhase(null);
    setNarrative([]);
    setPendingDecision(null);
    setPhaseTimers({});
    setEvents([]);
    setSystemLocked(false);
    setFinalOutcome(null);
    activePhaseStartRef.current = {};
  }, []);

  const handleRun = async () => {
    if (streamRef.current) {
      streamRef.current.close();
      streamRef.current = null;
    }
    resetUi();
    setStatus('running');
    try {
      const exec = await api.startExecution({
        workflow_slug: 'devops_pipeline',
        chaos_mode: chaosMode,
        policy_override: policyOverride,
      });
      setExecId(exec.id);
      const stream = new EventStream(exec.id, {
        onHello: () => {},
        onEvent: applyEvent,
        onReplayDone: () => {},
        onStatus: setConnState,
      });
      stream.connect();
      streamRef.current = stream;
    } catch (e) {
      console.error('start execution', e);
      setStatus('failed');
    }
  };

  const handleReset = () => {
    if (streamRef.current) {
      streamRef.current.close();
      streamRef.current = null;
    }
    setExecId(null);
    setStatus('idle');
    setConnState('disconnected');
    resetUi();
  };

  const handleDecision = async (actionId) => {
    if (!execId) return;
    try {
      await api.decide(execId, actionId);
    } catch (e) {
      console.error('decide', e);
    }
  };

  const handlePauseResume = async () => {
    if (!execId) return;
    if (status === 'paused') {
      await api.resume(execId);
    } else if (status === 'running') {
      await api.pause(execId);
    }
  };

  useEffect(() => {
    return () => { if (streamRef.current) streamRef.current.close(); };
  }, []);

  // Lazy fetch traces/circuits when tab opens
  useEffect(() => {
    if (!drawerOpen) return;
    if (drawerTab === 'traces' && execId) {
      api.traces(execId).then((d) => setTraces(d.spans || [])).catch(() => {});
    }
    if (drawerTab === 'circuits') {
      api.circuitBreakers().then((d) => setBreakers(d.breakers || [])).catch(() => {});
    }
  }, [drawerOpen, drawerTab, execId, events.length]);

  const phases = workflow?.phases || [];
  const nodesByPhase = useMemo(() => {
    if (!workflow) return {};
    const map = {};
    workflow.nodes.forEach((n) => {
      if (!map[n.phase]) map[n.phase] = [];
      map[n.phase].push(n);
    });
    return map;
  }, [workflow]);

  const releasePhaseId = phases.length ? phases[phases.length - 1].id : null;
  const artifactSegments = phases.map((p) => p.id);

  return (
    <div className="app-shell" data-testid="pipeline-studio">
      <header className="studio-header">
        <h1>
          Pipeline Studio <span className="badge">V13 · AGENTIC</span>
          {execId && (
            <span className="exec-id" data-testid="exec-id-label">
              <span className={`conn-dot ${connState === 'live' ? 'live' : connState === 'replay' ? 'replay' : ''}`} />
              exec: {execId.slice(0, 8)}… · {status}
            </span>
          )}
        </h1>

        <div className="controls">
          <label data-testid="chaos-toggle-label">
            <input
              type="checkbox"
              data-testid="chaos-toggle"
              checked={chaosMode}
              onChange={(e) => setChaosMode(e.target.checked)}
            />
            Chaos Mode
          </label>
          <label>
            Policy
            <select
              data-testid="policy-select"
              value={policyOverride}
              onChange={(e) => setPolicyOverride(e.target.value)}
            >
              <option value="human">Human</option>
              <option value="probabilistic">Probabilistic</option>
              <option value="rule">Rule-based</option>
              <option value="llm">LLM (Claude Sonnet 4.5)</option>
            </select>
          </label>
          <button data-testid="pause-resume-btn" onClick={handlePauseResume} disabled={!execId || (status !== 'running' && status !== 'paused')}>
            {status === 'paused' ? 'Resume' : 'Pause'}
          </button>
          <button data-testid="event-log-btn" onClick={() => setDrawerOpen((v) => !v)}>
            Events
          </button>
          <button data-testid="reset-btn" onClick={handleReset}>Reset</button>
          <button className="primary" data-testid="run-pipeline-btn" onClick={handleRun}>
            Run Pipeline
          </button>
        </div>
      </header>

      <main
        ref={stageRef}
        className={`stage ${systemLocked ? 'system-locked' : ''}`}
        data-testid="stage"
      >
        {phases.map((phase) => {
          const isActive = activePhase === phase.id;
          const timerSec = phaseTimers[phase.id] || 0;
          return (
            <div
              key={phase.id}
              id={`lane-${phase.id}`}
              className={`lane ${isActive ? 'active-phase' : ''}`}
              data-testid={`lane-${phase.id}`}
            >
              <div className="lane-header">
                <span className="lane-title">{phase.name}</span>
                <span className="lane-meta" data-testid={`timer-${phase.id}`}>{timerSec.toFixed(1)}s</span>
              </div>
              <div className="lane-content">
                {(nodesByPhase[phase.id] || []).map((node) => {
                  const st = nodeStates[node.id];
                  const cls = ['node', st || ''].filter(Boolean).join(' ');
                  return (
                    <div
                      key={node.id}
                      id={`node-${node.id}`}
                      className={cls}
                      data-role={node.role}
                      data-type={node.type}
                      data-testid={`node-${node.id}`}
                      title={`${node.name} (${node.type})`}
                    >
                      <Icon name={node.icon} />
                      <span className="node-label">{node.name}</span>
                    </div>
                  );
                })}
              </div>

              {phase.id === releasePhaseId && (
                <div className="artifact-container" data-testid="artifact-memory">
                  <svg viewBox="0 0 100 100">
                    {artifactSegments.map((segId, i) => {
                      const paths = [
                        'M50 50 L50 5 L93 35 Z',
                        'M50 50 L93 35 L78 88 Z',
                        'M50 50 L78 88 L22 88 Z',
                        'M50 50 L22 88 L7 35 Z',
                        'M50 50 L7 35 L50 5 Z',
                      ];
                      const mem = phaseMemory[segId];
                      const cls = mem ? `lit-${mem}` : '';
                      return <path key={segId} d={paths[i]} className={cls} />;
                    })}
                    <circle cx="50" cy="50" r="8" fill="#000" stroke="var(--c-border)" strokeWidth="1" />
                  </svg>
                </div>
              )}
            </div>
          );
        })}

        <svg ref={connectorSvgRef} className="connector-svg" />

        {pendingDecision && (
          <div className="decision-panel visible" data-testid="decision-panel">
            <div className="cmd-header" data-testid="decision-intent">
              {(pendingDecision.intent || 'Intervention Required').toUpperCase()}
            </div>
            {pendingDecision.policyHint && pendingDecision.policyHint.source !== 'human' && (
              <div className="cmd-policy-hint" data-testid="policy-hint">
                {pendingDecision.policyHint.source.toUpperCase()} · confidence{' '}
                {(pendingDecision.policyHint.confidence ?? 0).toFixed(2)}
                {pendingDecision.policyHint.reasoning ? ` · ${pendingDecision.policyHint.reasoning}` : ''}
              </div>
            )}
            {pendingDecision.options.map((opt) => (
              <button
                key={opt.action_id}
                className="cmd-btn"
                data-testid={`decision-option-${opt.action_id}`}
                onClick={() => handleDecision(opt.action_id)}
              >
                <span className={`sev-${opt.severity}`}>◆</span>
                {opt.label}
              </button>
            ))}
          </div>
        )}

        <div className={`event-log-drawer ${drawerOpen ? 'open' : ''}`} data-testid="event-log-drawer">
          <div className="event-log-header">
            <div style={{ display: 'flex', gap: 6 }}>
              {['events', 'traces', 'circuits'].map((t) => (
                <button
                  key={t}
                  data-testid={`drawer-tab-${t}`}
                  onClick={() => setDrawerTab(t)}
                  style={{
                    background: drawerTab === t ? 'var(--c-lane-alt)' : 'transparent',
                    border: '1px solid var(--c-border)',
                    color: drawerTab === t ? 'var(--c-text-main)' : 'var(--c-text-sub)',
                    padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
                    fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.08em',
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
            <button onClick={() => setDrawerOpen(false)} style={{ background: 'transparent', border: 'none', color: 'var(--c-text-sub)', cursor: 'pointer' }}>
              ✕
            </button>
          </div>
          <div className="event-log-body">
            {drawerTab === 'events' && events.map((ev) => (
              <div key={ev.id} className={`event-row sev-${ev.severity}`} data-testid={`event-row-${ev.seq}`}>
                <div className="seq">#{ev.seq}</div>
                <div>
                  <div className="type">{ev.type}</div>
                  <div className="desc">{ev.description}</div>
                </div>
              </div>
            ))}
            {drawerTab === 'traces' && (
              traces.length === 0 ? (
                <div style={{ padding: 20, color: 'var(--c-text-sub)', fontSize: '0.75rem' }}>
                  {execId ? 'No spans yet (execution still running?)' : 'Start an execution to view traces'}
                </div>
              ) : traces.map((s, i) => (
                <div key={i} className="event-row" data-testid={`trace-row-${i}`}>
                  <div className="seq">{s.duration_ms ? `${s.duration_ms.toFixed(1)}ms` : '—'}</div>
                  <div>
                    <div className="type">{s.name}</div>
                    <div className="desc">
                      {s.attributes?.['node.name'] || s.attributes?.['node.id'] || ''}
                      {s.attributes?.['node.outcome'] ? ` · ${s.attributes['node.outcome']}` : ''}
                      {s.attributes?.['policy.mode'] ? ` · ${s.attributes['policy.mode']} (conf ${(s.attributes['policy.confidence'] ?? 0).toFixed?.(2) ?? s.attributes['policy.confidence']})` : ''}
                      {s.attributes?.attempt ? ` · attempt ${s.attributes.attempt}` : ''}
                    </div>
                  </div>
                </div>
              ))
            )}
            {drawerTab === 'circuits' && (
              breakers.length === 0 ? (
                <div style={{ padding: 20, color: 'var(--c-text-sub)', fontSize: '0.75rem' }}>
                  No circuit breakers registered yet
                </div>
              ) : breakers.map((b, i) => (
                <div key={i} className={`event-row sev-${b.state === 'open' ? 'critical' : b.state === 'half_open' ? 'warning' : 'clean'}`} data-testid={`circuit-row-${b.key}`}>
                  <div className="seq">{b.state.toUpperCase()}</div>
                  <div>
                    <div className="type">{b.key}</div>
                    <div className="desc">
                      {b.failures_in_window}/{b.failure_threshold} failures in {b.window_s}s
                      {b.open_duration_s ? ` · cool-down ${b.open_duration_s}s` : ''}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>

      <footer
        className="summary-strip"
        data-testid="narrative-strip"
        style={{ borderTopColor: finalOutcome === 'completed' ? 'var(--s-success)' : finalOutcome === 'failed' ? 'var(--s-failure)' : 'var(--c-border)' }}
      >
        {narrative.length === 0 ? (
          <span>{execId ? 'Awaiting first narrative event…' : 'READY'}</span>
        ) : (
          narrative.map((item, i) => (
            <span key={i}>
              <span className={`narrative-${item.severity || 'clean'}`}>{item.text}</span>
              {i < narrative.length - 1 && <span className="narrative-arrow">→</span>}
            </span>
          ))
        )}
      </footer>
    </div>
  );
}
