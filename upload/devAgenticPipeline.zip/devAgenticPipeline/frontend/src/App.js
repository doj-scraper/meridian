import React from 'react';
import './App.css';
import PipelineStudio from './components/PipelineStudio';

function App() {
  return <PipelineStudio />;
}

export default App;
