# Architecture

This document describes the runtime architecture of the Pipeline Studio
orchestrator. For agent-specific concerns (handlers, policies, prompts) see
[`AGENTS.md`](./AGENTS.md).

---

## High-level layers

```
        ┌──────────────────────────────────────────────┐
        │               React UI (renderer)            │
        │   PipelineStudio.jsx · Icons · orchestratorClient.js │
        └──────┬─────────────────────────────┬─────────┘
               │ REST /api/*                 │ WS /api/ws/executions/{id}
               ▼                             ▼
        ┌──────────────────────────────────────────────┐
        │            FastAPI transport layer           │
        │               server.py                      │
        └──────┬────────────────────┬───────────┬──────┘
               │                    │           │
               ▼                    ▼           ▼
        ┌─────────────┐      ┌──────────┐  ┌──────────────┐
        │ Orchestrator│◄────►│ Agents   │  │ Policies     │
        │ (async loop)│      │ registry │  │ registry     │
        └──────┬──────┘      └──────────┘  └──────────────┘
               │
               ├──► Tracing (OTEL, in-memory + OTLP)
               ├──► CircuitBreakerRegistry
               ├──► EventBus ──► WebSocket subscribers
               │
               ▼
        ┌──────────────────────────────────────────────┐
        │             MongoDB persistence              │
        │   workflows · executions · events (append)   │
        └──────────────────────────────────────────────┘
```

The **engine** is UI-agnostic. The **UI** is a pure renderer: it fetches a
workflow definition and subscribes to the event stream for its execution.

---

## Workflow model

A workflow is a declarative DAG + state-machine hybrid:

```json
{
  "slug": "devops_pipeline",
  "version": 1,
  "entry_node_id": "n1",
  "phases": [{ "id": "design", "name": "Design", "order": 1 }, ...],
  "nodes":  [{ "id": "n1", "type": "action", "handler": "simulate", ... }, ...],
  "edges":  [{ "from": "n1", "to": "n2", "severity": "clean" }, ...]
}
```

- **Phases** are purely organisational metadata (lane groupings + narrative).
- **Nodes** are one of: `action` (runs an agent), `decision` (delegates to a
  policy), or `terminal` (end / passthrough).
- **Edges** have an optional `condition` (`success` / `failure`) used by action
  nodes, and an optional `action_id` used by decision nodes.

Every node can declare:

| Field              | Purpose                                              |
| ------------------ | ---------------------------------------------------- |
| `retry_policy`     | `max_attempts`, `base_backoff_s`, `max_backoff_s`    |
| `timeout_s`        | Per-attempt wall-clock timeout                       |
| `compensation`     | Id of a rollback/compensation node                   |
| `failure_probability` | Used by chaos mode to inject failures             |
| `circuit_breaker`  | `enabled`, `key`, `failure_threshold`, `window_s`, `open_duration_s` |
| `policy`           | Decision-only: `mode`, `llm_model`, `min_confidence`, `rules` |

---

## Persistence model

Three MongoDB collections:

### `workflows`
Versioned definitions, uniquely keyed by `(slug, version)`. Loaded on
orchestrator startup (DevOps pipeline is seeded idempotently from
`backend/workflows/devops_pipeline.json`).

### `executions`
One document per run. Contains:

- `id` — UUID
- `workflow_id`, `workflow_slug`, `workflow_version`
- `status` — `pending | running | awaiting_decision | paused | completed | failed`
- `current_node_id`, `pending_decision_node_id`
- `version` — **optimistic concurrency token**; every save matches on the
  expected version and bumps it atomically
- `seq` — event sequence counter (kept in lock-step with the `events`
  collection)
- `context` — shared dict passed to every agent
- `phase_memory` — highest severity seen per phase (`clean | warning | critical`)
- `node_attempts`, `node_results` — idempotency cache
- `chaos_mode`, `policy_override`
- `started_at`, `finished_at`, `last_error`

### `events`
Append-only log. Unique index on `(execution_id, seq)` guarantees replay
determinism. Events carry `type`, `severity`, `description`, `payload`,
and a UTC `ts`. Every state transition emits at least one event.

---

## Execution lifecycle

```
  start_execution()      submit_decision()     resume_execution()
        │                      │                     │
        ▼                      ▼                     ▼
   PENDING ─► RUNNING ◄─► AWAITING_DECISION ◄─► PAUSED
                 │
         ┌───────┴────────┐
         ▼                ▼
      COMPLETED         FAILED
```

`_run_loop(exec_id)`:

1. Load state once (no mid-loop reloads — the in-memory state is
   authoritative while the loop holds it).
2. Check pause flag → persist & exit.
3. Resolve current node:
   - **action** → `_execute_action` with retries + backoff + circuit breaker.
   - **decision** → `_resolve_decision` with policy; if `needs_human`, emit
     `decision_required`, persist, block on an `asyncio.Event`.
   - **terminal** → emit and follow trailing edges, or complete the workflow.
4. Advance `current_node_id`, save, continue.

External control (pause / resume / decide) communicates with the loop through
a per-execution `_flags` dict, not by mutating DB state directly — this
avoids optimistic-lock contention with the running loop.

---

## Event emission + streaming

- `_emit(state, type, ...)` bumps `state.seq`, inserts into `events`, and
  publishes to an in-process `EventBus`.
- `EventBus` holds a set of `asyncio.Queue`s per `execution_id`. The
  WebSocket handler creates a queue on subscribe, forwards events until the
  socket closes, then unsubscribes.
- On WebSocket connect (`/api/ws/executions/{id}?from_seq=N`):
  1. Send `_hello` with the current execution state.
  2. Read stored events with `seq >= N` and replay them in order.
  3. Send `_replay_done` with the last seq.
  4. Forward live events, de-duping anything already replayed.
  5. Send `_ping` every 30s as keepalive.

This gives clean reconnect semantics: the UI remembers the last seq it
rendered and can reconnect without losing or duplicating state.

---

## Concurrency model

- Single-process, single event loop for the MVP.
- Per-execution task is an `asyncio.Task` spawned from
  `start_execution` / `resume_execution` / `submit_decision`.
- MongoDB writes on `executions` use optimistic concurrency via the `version`
  field. The orchestrator is the sole writer, so contention is rare; the
  unique `(execution_id, seq)` index on `events` catches any accidental
  double-emit.
- Multi-worker distribution is **not implemented**. The schema supports it
  (version leases, event-sourced recovery), but you'd need to add a worker
  id + heartbeat layer on top.

---

## Failure handling

The orchestrator distinguishes four failure modes:

1. **Transient** — handled by retry + exponential backoff on the node's
   `retry_policy`.
2. **Persistent** — after attempts exhausted, the node is marked failed, the
   declared `failure` edge is followed, and (if present) the `compensation`
   node is triggered (rollback).
3. **Systemic** — per-handler circuit breaker trips on N failures within a
   rolling window; subsequent calls short-circuit directly to the failure
   edge. Emits `circuit_opened` / `circuit_short_circuited`. After
   `open_duration_s`, the breaker moves to HALF_OPEN and lets a single probe
   through; success closes, failure reopens.
4. **Unknown** — any unhandled exception in the loop is caught at the
   top-level; the execution is marked `FAILED` and a `workflow_failed` event
   is emitted.

---

## Observability

Two subsystems, both exposed via REST:

- **Event log** (`GET /api/executions/{id}/events`) — durable, ordered,
  canonical source of truth.
- **OpenTelemetry traces** (`GET /api/executions/{id}/traces`) — in-memory
  collector keyed by `execution.id` attribute. Spans:
  - `workflow.execution` — root span per execution attempt
  - `workflow.node` — one per node visited
  - `agent.attempt` — one per retry attempt
  - `policy.decide` — per policy invocation, with
    `policy.mode`, `policy.source`, `policy.confidence`, `policy.action_id`.

Setting `OTEL_EXPORTER_OTLP_ENDPOINT` enables BatchSpanProcessor export to an
OTLP collector (Jaeger / Tempo / Honeycomb / any OTLP-compatible backend)
**in addition to** the in-memory store.

---

## Security posture

- No authentication layer yet. All `/api/*` endpoints are open; safe only
  behind the platform ingress in a single-tenant demo context.
- `EMERGENT_LLM_KEY` is the only secret; it is read from the backend `.env`
  at startup and passed to `emergentintegrations.LlmChat`.
- Mongo credentials come from `MONGO_URL`; no hard-coded defaults.

Do not deploy to a public environment without adding authN/authZ and TLS for
the WebSocket.
